// Shared screens: landing, language, OTP login, info pages, notifications, deletion, errors.
import { api } from "../api.js";
import { PRIVACY, TERMS } from "../content.js";
import { fmtDate, getLang, num, setLang, t } from "../i18n.js";
import { go } from "../router.js";
import { state } from "../state.js";
import { clear, confirmDialog, field, h, icon, input, load, pager, showError, toast } from "../ui.js";
import { refreshMe, renderChrome, view } from "../app.js";

const page = (...children) => clear(view()).append(h("div.page", ...children));
const homeFor = role => ({ patient: "/home", therapist: "/therapist", admin: "/admin" }[role] || "/home");

export function landing() {
  page(
    h("section.hero",
      h("div.hero-mark", icon("shield")),
      h("h1.hero-title", "CHINI | চিনি"),
      h("p.motto.motto-lg", "চিনুন আসল থেরাপিস্ট"),
      h("p.lead", t("landing.lead")),
      h("div.stack",
        h("a.btn.btn-primary.btn-lg.btn-block", { href: "#/home" }, t("landing.find")),
        h("a.btn.btn-secondary.btn-lg.btn-block", { href: "#/login?role=therapist" }, t("landing.therapist"))),
      h("a.link", { href: "#/verification" }, t("landing.how"))),
    footerLinks());
}

export function language() {
  const choose = l => () => { setLang(l); renderChrome(); go(state.user ? homeFor(state.user.role) : "/welcome", true); };
  page(
    h("div.center-col",
      h("h1", "CHINI | চিনি"), h("p.motto", "চিনুন আসল থেরাপিস্ট"),
      h("h2.h3", "ভাষা বেছে নিন / Choose your language"),
      h("div.stack",
        h("button.btn.btn-lang", { type: "button", on: { click: choose("bn") } }, "বাংলা"),
        h("button.btn.btn-lang", { type: "button", on: { click: choose("en") } }, "English")),
      h("p.muted", t("lang.subtitle"))));
}

export function login({ query }) {
  if (state.user) return go(homeFor(state.user.role), true);
  const role = query.get("role") === "therapist" ? "therapist" : (state.pendingRole || "patient");
  state.pendingRole = role;
  const phone = input({ name: "phone", type: "tel", inputmode: "numeric", autocomplete: "tel-national",
    placeholder: t("login.phone_ph"), maxlength: 20, required: true, value: state.pendingPhone || "" });
  const btn = h("button.btn.btn-primary.btn-block", { type: "submit" }, t("login.send"));
  const form = h("form.card.form", { novalidate: true, on: { submit: async e => {
    e.preventDefault();
    btn.disabled = true; btn.textContent = t("login.sending");
    try {
      const res = await api.post("/api/auth/otp/request", { phone: phone.value });
      state.pendingPhone = phone.value; state.otpInfo = res; state.otpSentAt = Date.now();
      go("/otp");
    } catch (err) { showError(err); phone.classList.add("invalid"); }
    finally { btn.disabled = false; btn.textContent = t("login.send"); }
  } } },
    h("h1.h2", role === "therapist" ? t("login.therapist_title") : t("login.title")),
    state.config?.otp_dev_mode ? h("div.alert.alert-warn", t("login.dev_banner")) : null,
    field(t("login.phone"), phone),
    btn, h("p.muted.small", t("login.privacy")));
  page(form,
    role === "patient" ? h("a.link.center", { href: "#/login?role=therapist" }, t("landing.therapist"))
      : h("a.link.center", { href: "#/login?role=patient" }, t("landing.find")));
  phone.focus();
}

export function otp() {
  if (!state.pendingPhone) return go("/login", true);
  const code = input({ name: "code", inputmode: "numeric", autocomplete: "one-time-code", maxlength: 6,
    pattern: "[0-9০-৯]*", class: "otp-input", required: true });
  const btn = h("button.btn.btn-primary.btn-block", { type: "submit" }, t("otp.verify"));
  const resend = h("button.btn.btn-ghost", { type: "button" });
  let timer;
  const tick = () => {
    const left = Math.ceil(((state.otpInfo?.resend_in || 60) * 1000 - (Date.now() - state.otpSentAt)) / 1000);
    if (left > 0) { resend.disabled = true; resend.textContent = t("otp.resend_in", { s: left }); }
    else { resend.disabled = false; resend.textContent = t("otp.resend"); clearInterval(timer); }
  };
  timer = setInterval(tick, 1000); tick();
  resend.addEventListener("click", async () => {
    try {
      state.otpInfo = await api.post("/api/auth/otp/request", { phone: state.pendingPhone });
      state.otpSentAt = Date.now(); timer = setInterval(tick, 1000); tick();
    } catch (err) { showError(err); }
  });
  const form = h("form.card.form", { on: { submit: async e => {
    e.preventDefault();
    btn.disabled = true; btn.textContent = t("otp.verifying");
    try {
      const res = await api.post("/api/auth/otp/verify", { phone: state.pendingPhone, code: code.value,
        role: state.pendingRole || "patient", language: getLang() });
      clearInterval(timer);
      state.user = res.user; state.csrf = res.csrf_token; state.pendingPhone = null;
      await refreshMe();
      if (res.user.role === "patient") api.get("/api/patient/saved/ids").then(ids => { state.savedIds = new Set(ids); }).catch(() => {});
      const back = state.returnTo; state.returnTo = null;
      if (res.next === "create_profile") go("/onboarding", true);
      else if (res.next === "application") go("/therapist", true);
      else go(back || homeFor(res.user.role), true);
    } catch (err) { showError(err); code.select(); }
    finally { btn.disabled = false; btn.textContent = t("otp.verify"); }
  } } },
    h("h1.h2", t("otp.title")),
    h("p.muted", t("otp.sent_to", { phone: state.otpInfo?.phone_masked || state.pendingPhone })),
    state.otpInfo?.dev_mode ? h("div.alert.alert-warn", t("login.dev_banner")) : null,
    field(t("otp.code"), code), btn,
    h("div.row-between", h("a.link", { href: "#/login" }, t("otp.change")), resend));
  page(form);
  code.focus();
}

export function verification() {
  page(h("article.card.prose",
    h("div.hero-mark.small", icon("shield")), h("h1.h2", t("verify.title")),
    h("p", t("verify.p1")), h("p", t("verify.p2")), h("p", t("verify.p3")),
    h("a.btn.btn-primary", { href: "#/search" }, t("landing.find"))));
}

export function help() {
  const cfg = state.config || {};
  page(h("article.card.prose",
    h("h1.h2", t("help.title")),
    ...[1, 2, 3].map(i => h("details.faq", h("summary", t(`help.faq${i}q`)), h("p", t(`help.faq${i}a`)))),
    h("h2.h3", t("help.contact")),
    cfg.support_email ? h("p", h("a", { href: "mailto:" + cfg.support_email }, cfg.support_email)) : null,
    cfg.support_phone ? h("p", h("a", { href: "tel:" + cfg.support_phone }, cfg.support_phone)) : null,
    h("p", h("a.link", { href: "#/verification" }, t("home.learn_verify")))), footerLinks());
}

function legal(title, sections) {
  const email = state.config?.support_email || "";
  page(h("article.card.prose", h("h1.h2", title),
    ...(sections[getLang()] || sections.en).map(([hd, body]) => [h("h2.h3", hd), h("p", body.replace("{email}", email))])),
    footerLinks());
}
export const privacy = () => legal(t("privacy.title"), PRIVACY);
export const terms = () => legal(t("terms.title"), TERMS);

export function notifications() {
  const body = h("div");
  const show = async (p = 1) => load(body, async () => {
    const data = await api.get("/api/notifications", { page: p, page_size: 20 });
    if (!data.items.length) return h("div.state-block.empty", t("notif.empty"));
    return [h("ul.list", data.items.map(n => h("li.list-item" + (n.read_at ? "" : ".unread"),
      h("p", t("notif." + n.type, Object.fromEntries(Object.entries(n.payload || {}).map(([k, v]) => [k, v ?? ""])))),
      h("small.muted", fmtDate(n.created_at, true))))),
      pager(data, show)];
  });
  page(h("div.row-between", h("h1.h2", t("notif.title")),
    h("button.btn.btn-ghost.btn-sm", { type: "button", on: { click: async () => {
      try { await api.post("/api/notifications/read"); if (state.user) state.user.unread_notifications = 0; renderChrome(); show(); }
      catch (err) { showError(err); }
    } } }, t("notif.mark_all"))), body);
  show();
}

export function accountDelete() {
  page(h("div.card.prose",
    h("h1.h2", t("del.title")), h("p", t("del.lead")),
    h("button.btn.btn-danger", { type: "button", on: { click: async () => {
      if (!(await confirmDialog(t("del.title"), t("del.lead"), t("del.confirm"), true))) return;
      try {
        await api.post("/api/account/deletion-request");
        toast(t("del.done"));
        await api.post("/api/auth/logout-all").catch(() => {});
        state.user = null; state.csrf = null; renderChrome(); go("/welcome", true);
      } catch (err) { showError(err); }
    } } }, t("del.confirm"))));
}

export function offline() {
  page(h("div.state-block", h("h1.h2", t("err.offline_title")), h("p", t("err.network")),
    h("button.btn.btn-primary", { type: "button", on: { click: () => history.back() } }, t("common.retry"))));
}

export function notFound() {
  page(h("div.state-block", h("h1.h2", t("err.not_found")), h("p", t("err.not_found_lead")),
    h("a.btn.btn-primary", { href: "#/" }, t("err.go_home"))));
}

export function footerLinks() {
  return h("footer.footer-links",
    h("a", { href: "#/privacy" }, t("footer.privacy")), h("a", { href: "#/terms" }, t("footer.terms")),
    h("a", { href: "#/help" }, t("footer.help")), h("a", { href: "#/verification" }, t("landing.how")),
    state.user && state.user.role !== "admin" ? h("a", { href: "#/account/delete" }, t("footer.delete")) : null);
}

export { num };
