// Long-form legal text. TEMPLATE ONLY — have a Bangladeshi lawyer review before public launch.
export const PRIVACY = {
  en: [
    ["Who we are", "CHINI is a directory that helps people in Bangladesh find physiotherapists, occupational therapists and speech & language therapists whose documents we have reviewed. Contact: {email}."],
    ["What we collect from patients", "Your verified mobile number, your name, optional email, your address (house, road, thana, upazila, district, division), language preference, therapists you save, call taps you make in the app, and appointment requests you send. We do not ask for your medical history, diagnoses or prescriptions."],
    ["What we collect from therapists", "Identity details (name, date of birth, National ID number), contact details, qualifications, registration details, practice information, a profile photo and the documents you upload for verification."],
    ["How we use it", "To sign you in with a one-time SMS code, to show verified therapists, to keep your saved list, to deliver appointment requests, to review therapist credentials, to prevent fraud and abuse, and to keep the service secure."],
    ["Who can see what", "Patients' addresses are never shown to therapists. A therapist sees your name and mobile number only if you send them an appointment request or choose to share your details when calling. Therapists' private documents, National ID, date of birth and marks are visible only to CHINI reviewers, never on public pages."],
    ["Storage and security", "Data is sent over HTTPS. Documents are kept in private storage that is not publicly accessible. Access by staff is limited and recorded in an audit log."],
    ["SMS provider", "We send login codes through an SMS provider, which receives your phone number for that purpose."],
    ["Retention", "We keep your account data while your account is active. If you ask us to delete your account we remove your personal data within 30 days, except records we must keep for security or legal reasons, which are kept without your personal details where possible."],
    ["Your choices", "You can edit your profile, remove saved therapists, stop sharing your details with a therapist, sign out on all devices, and request deletion of your account in the app."],
    ["Changes", "We will tell you in the app if this policy changes in an important way."],
  ],
  bn: [
    ["আমরা কারা", "চিনি একটি তালিকা, যা বাংলাদেশের মানুষকে এমন ফিজিওথেরাপিস্ট, অকুপেশনাল থেরাপিস্ট ও স্পিচ অ্যান্ড ল্যাঙ্গুয়েজ থেরাপিস্ট খুঁজে পেতে সাহায্য করে যাঁদের কাগজপত্র আমরা যাচাই করেছি। যোগাযোগ: {email}।"],
    ["রোগীদের কাছ থেকে যা সংগ্রহ করি", "আপনার যাচাইকৃত মোবাইল নম্বর, নাম, ঐচ্ছিক ইমেইল, ঠিকানা (বাড়ি, রোড, থানা, উপজেলা, জেলা, বিভাগ), ভাষা, আপনার সংরক্ষিত থেরাপিস্ট, অ্যাপে কল বোতাম চাপার তথ্য এবং অ্যাপয়েন্টমেন্ট অনুরোধ। আমরা আপনার রোগের ইতিহাস, রোগনির্ণয় বা প্রেসক্রিপশন চাই না।"],
    ["থেরাপিস্টদের কাছ থেকে যা সংগ্রহ করি", "পরিচয়ের তথ্য (নাম, জন্ম তারিখ, জাতীয় পরিচয়পত্র নম্বর), যোগাযোগের তথ্য, শিক্ষাগত যোগ্যতা, নিবন্ধনের তথ্য, পেশাগত তথ্য, প্রোফাইল ছবি এবং যাচাইয়ের জন্য আপলোড করা কাগজপত্র।"],
    ["কীভাবে ব্যবহার করি", "এসএমএস কোড দিয়ে লগ ইন করাতে, যাচাইকৃত থেরাপিস্ট দেখাতে, আপনার সংরক্ষিত তালিকা রাখতে, অ্যাপয়েন্টমেন্ট অনুরোধ পৌঁছাতে, থেরাপিস্টের কাগজপত্র যাচাই করতে, প্রতারণা ঠেকাতে এবং সেবা নিরাপদ রাখতে।"],
    ["কে কী দেখতে পায়", "রোগীর ঠিকানা কখনো থেরাপিস্টকে দেখানো হয় না। আপনি অ্যাপয়েন্টমেন্ট অনুরোধ পাঠালে বা কল করার সময় নিজে শেয়ার করলে তবেই থেরাপিস্ট আপনার নাম ও মোবাইল নম্বর দেখেন। থেরাপিস্টের গোপন কাগজপত্র, জাতীয় পরিচয়পত্র, জন্ম তারিখ ও নম্বর শুধু চিনির পর্যালোচকরা দেখতে পান — কখনো পাবলিক পৃষ্ঠায় নয়।"],
    ["সংরক্ষণ ও নিরাপত্তা", "তথ্য HTTPS-এর মাধ্যমে পাঠানো হয়। কাগজপত্র গোপন স্টোরেজে রাখা হয় যা সবার জন্য উন্মুক্ত নয়। কর্মীদের প্রবেশাধিকার সীমিত এবং অডিট লগে রেকর্ড হয়।"],
    ["এসএমএস সেবাদাতা", "লগ ইন কোড পাঠাতে আমরা একটি এসএমএস সেবাদাতা ব্যবহার করি, যারা এ উদ্দেশ্যে আপনার ফোন নম্বর পায়।"],
    ["তথ্য কতদিন রাখি", "অ্যাকাউন্ট চালু থাকা পর্যন্ত তথ্য রাখি। অ্যাকাউন্ট মুছতে বললে ৩০ দিনের মধ্যে ব্যক্তিগত তথ্য মুছে ফেলি; তবে নিরাপত্তা বা আইনি কারণে যা রাখা বাধ্যতামূলক তা সম্ভব হলে ব্যক্তিগত তথ্য ছাড়া রাখা হয়।"],
    ["আপনার পছন্দ", "আপনি প্রোফাইল সম্পাদনা, সংরক্ষিত থেরাপিস্ট সরানো, থেরাপিস্টের সাথে তথ্য শেয়ার বন্ধ, সব ডিভাইস থেকে লগ আউট এবং অ্যাপ থেকেই অ্যাকাউন্ট মুছে ফেলার অনুরোধ করতে পারেন।"],
    ["পরিবর্তন", "এই নীতিতে গুরুত্বপূর্ণ পরিবর্তন হলে আমরা অ্যাপে জানাব।"],
  ],
};

export const TERMS = {
  en: [
    ["Using CHINI", "CHINI helps you find and contact therapists. CHINI does not provide treatment and is not a party to any agreement between you and a therapist."],
    ["What verification means", "“Verified by CHINI” means our reviewers checked the documents a therapist submitted. CHINI is not a government regulator or licensing authority and does not guarantee the quality or outcome of any treatment."],
    ["Therapists' responsibilities", "Therapists must submit true, current information and documents that belong to them, keep their profile accurate, and protect patient information. False information leads to rejection, suspension or removal."],
    ["Patients' responsibilities", "Use the service lawfully, do not misuse therapists' contact details, and report profiles that look wrong."],
    ["Appointments", "An appointment request is not confirmed until the therapist accepts it. Saving a therapist is not a booking."],
    ["Emergencies", "CHINI is not an emergency service. In an emergency call 999 or go to the nearest hospital."],
    ["Suspension", "We may suspend or remove accounts that break these terms or put others at risk."],
    ["Contact", "Questions: {email}."],
  ],
  bn: [
    ["চিনি ব্যবহার", "চিনি আপনাকে থেরাপিস্ট খুঁজে পেতে ও যোগাযোগ করতে সাহায্য করে। চিনি নিজে চিকিৎসা দেয় না এবং আপনার ও থেরাপিস্টের মধ্যকার কোনো চুক্তির পক্ষ নয়।"],
    ["যাচাইয়ের মানে", "“চিনি যাচাইকৃত” মানে আমাদের পর্যালোচকরা থেরাপিস্টের জমা দেওয়া কাগজপত্র যাচাই করেছেন। চিনি কোনো সরকারি নিয়ন্ত্রক বা লাইসেন্সদাতা সংস্থা নয় এবং চিকিৎসার মান বা ফলাফলের নিশ্চয়তা দেয় না।"],
    ["থেরাপিস্টদের দায়িত্ব", "থেরাপিস্টদের সত্য, হালনাগাদ তথ্য ও নিজের কাগজপত্র জমা দিতে হবে, প্রোফাইল সঠিক রাখতে হবে এবং রোগীর তথ্য সুরক্ষিত রাখতে হবে। মিথ্যা তথ্যের কারণে আবেদন বাতিল, স্থগিত বা অপসারণ হতে পারে।"],
    ["রোগীদের দায়িত্ব", "আইনসম্মতভাবে সেবা ব্যবহার করুন, থেরাপিস্টের যোগাযোগের তথ্যের অপব্যবহার করবেন না এবং ভুল মনে হলে প্রোফাইল রিপোর্ট করুন।"],
    ["অ্যাপয়েন্টমেন্ট", "থেরাপিস্ট গ্রহণ না করা পর্যন্ত অ্যাপয়েন্টমেন্ট অনুরোধ নিশ্চিত নয়। থেরাপিস্ট সংরক্ষণ করা বুকিং নয়।"],
    ["জরুরি অবস্থা", "চিনি জরুরি সেবা নয়। জরুরি প্রয়োজনে ৯৯৯-এ কল করুন বা নিকটস্থ হাসপাতালে যান।"],
    ["স্থগিতকরণ", "এই শর্ত ভঙ্গ করলে বা অন্যদের ঝুঁকিতে ফেললে আমরা অ্যাকাউন্ট স্থগিত বা অপসারণ করতে পারি।"],
    ["যোগাযোগ", "প্রশ্ন থাকলে: {email}।"],
  ],
};
