// Translation dictionary lookup. All UI text goes through t(); no duplicated pages per language.
import bn from "./lang/bn.js";
import en from "./lang/en.js";

const DICTS = { bn, en };
const BN_DIGITS = "০১২৩৪৫৬৭৮৯";
let lang = "bn";

export function storedLang() {
  try { return localStorage.getItem("chini.lang"); } catch { return null; }
}

export function setLang(l) {
  lang = DICTS[l] ? l : "bn";
  try { localStorage.setItem("chini.lang", lang); } catch { /* storage unavailable */ }
  document.documentElement.lang = lang;
}

export function getLang() { return lang; }

export function t(key, params = {}) {
  let s = DICTS[lang][key] ?? DICTS.en[key] ?? key;
  for (const [k, v] of Object.entries(params)) s = s.replaceAll(`{${k}}`, num(v));
  return s;
}

/** Localise digits for display in Bengali (data values stay ASCII). */
export function num(v) {
  if (v === null || v === undefined) return "";
  const s = String(v);
  return lang === "bn" ? s.replace(/[0-9]/g, d => BN_DIGITS[d]) : s;
}

/** Pick the Bengali or English column of a bilingual record. */
export function nm(obj, base = "name") {
  if (!obj) return "";
  return (lang === "bn" ? obj[`${base}_bn`] : obj[`${base}_en`]) || obj[`${base}_en`] || obj[`${base}_bn`] || "";
}

export function fmtDate(iso, withTime = false) {
  if (!iso) return "";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  const opts = withTime ? { dateStyle: "medium", timeStyle: "short" } : { dateStyle: "medium" };
  return d.toLocaleString(lang === "bn" ? "bn-BD" : "en-GB", opts);
}
