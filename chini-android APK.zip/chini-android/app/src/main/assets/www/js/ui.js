// UI helpers. Text is always inserted with textContent — never innerHTML with data — to prevent XSS.
import { api, ApiError } from "./api.js";
import { fmtDate, nm, num, t } from "./i18n.js";
import { state } from "./state.js";

/** h("div.card#id", {attrs, on:{click}}, ...children) */
export function h(spec, attrs, ...children) {
  if (attrs === null || typeof attrs !== "object" || attrs instanceof Node || Array.isArray(attrs)) {
    children.unshift(attrs); attrs = {};
  }
  const [, tag = "div", rest = ""] = spec.match(/^([a-z0-9-]*)(.*)$/i);
  const el = document.createElement(tag || "div");
  for (const part of rest.match(/[.#][^.#]+/g) || []) {
    if (part[0] === ".") el.classList.add(part.slice(1)); else el.id = part.slice(1);
  }
  for (const [k, v] of Object.entries(attrs)) {
    if (v === undefined || v === null || v === false) continue;
    if (k === "on") for (const [ev, fn] of Object.entries(v)) el.addEventListener(ev, fn);
    else if (k === "class") el.className += " " + v;
    else if (k === "style") el.setAttribute("style", v);
    else if (k === "dataset") Object.assign(el.dataset, v);
    else if (k in el && typeof v !== "string") el[k] = v;
    else el.setAttribute(k, v === true ? "" : v);
  }
  append(el, children);
  return el;
}

function append(el, children) {
  for (const c of children.flat(Infinity)) {
    if (c === null || c === undefined || c === false) continue;
    el.append(c instanceof Node ? c : document.createTextNode(String(c)));
  }
}

export function clear(el) { while (el.firstChild) el.removeChild(el.firstChild); return el; }

export function icon(name) {
  const paths = {
    home: "M3 11 12 3l9 8v10h-6v-6H9v6H3z", search: "M10 3a7 7 0 1 0 4.2 12.6L20 21.4 21.4 20l-5.8-5.8A7 7 0 0 0 10 3zm0 2a5 5 0 1 1 0 10 5 5 0 0 1 0-10z",
    heart: "M12 21s-7.5-4.6-9.5-9.3C1 8 3.4 4.5 7 4.5c2 0 3.4 1.1 5 2.9 1.6-1.8 3-2.9 5-2.9 3.6 0 6 3.5 4.5 7.2C19.5 16.4 12 21 12 21z",
    user: "M12 12a5 5 0 1 0 0-10 5 5 0 0 0 0 10zm-8 9a8 8 0 0 1 16 0z",
    grid: "M3 3h8v8H3zm10 0h8v8h-8zM3 13h8v8H3zm10 0h8v8h-8z",
    users: "M9 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8zm8 1a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM1 21a8 8 0 0 1 16 0zm16.5 0a9.5 9.5 0 0 0-2.6-6.5A6 6 0 0 1 23 21z",
    bell: "M12 22a2.5 2.5 0 0 0 2.5-2.5h-5A2.5 2.5 0 0 0 12 22zm7-6V11a7 7 0 0 0-5-6.7V3a2 2 0 1 0-4 0v1.3A7 7 0 0 0 5 11v5l-2 2v1h18v-1z",
    phone: "M6.6 10.8a15.1 15.1 0 0 0 6.6 6.6l2.2-2.2a1 1 0 0 1 1-.25 11.4 11.4 0 0 0 3.6.57 1 1 0 0 1 1 1V20a1 1 0 0 1-1 1A17 17 0 0 1 3 4a1 1 0 0 1 1-1h3.5a1 1 0 0 1 1 1c0 1.25.2 2.45.57 3.6a1 1 0 0 1-.25 1z",
    pin: "M12 2a7 7 0 0 0-7 7c0 5.2 7 13 7 13s7-7.8 7-13a7 7 0 0 0-7-7zm0 9.5A2.5 2.5 0 1 1 12 6.5a2.5 2.5 0 0 1 0 5z",
    check: "M9 16.2 4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4z", shield: "M12 2 4 5v6c0 5 3.4 9.7 8 11 4.6-1.3 8-6 8-11V5zm-1.2 14.2-3.5-3.5 1.4-1.4 2.1 2.1 4.9-4.9 1.4 1.4z",
    copy: "M16 1H4a2 2 0 0 0-2 2v14h2V3h12zm3 4H8a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h11a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2zm0 16H8V7h11z",
    back: "M20 11H7.8l5.6-5.6L12 4l-8 8 8 8 1.4-1.4L7.8 13H20z", globe: "M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm6.9 6h-3a15.7 15.7 0 0 0-1.4-3.6A8 8 0 0 1 18.9 8zM12 4c.8 1.2 1.5 2.5 1.9 4h-3.8c.4-1.5 1.1-2.8 1.9-4zM4.3 14a8.2 8.2 0 0 1 0-4h3.4a16.5 16.5 0 0 0 0 4zm.8 2h3a15.7 15.7 0 0 0 1.4 3.6A8 8 0 0 1 5.1 16zm3-8h-3a8 8 0 0 1 4.4-3.6A15.7 15.7 0 0 0 8.1 8zM12 20c-.8-1.2-1.5-2.5-1.9-4h3.8c-.4 1.5-1.1 2.8-1.9 4zm2.3-6H9.7a14.7 14.7 0 0 1 0-4h4.6a14.7 14.7 0 0 1 0 4zm.3 5.6a15.7 15.7 0 0 0 1.4-3.6h3a8 8 0 0 1-4.4 3.6zM16.3 14a16.5 16.5 0 0 0 0-4h3.4a8.2 8.2 0 0 1 0 4z",
  };
  const svg = document.createElementNS("http://www.w3.org/2000/svg", "svg");
  svg.setAttribute("viewBox", "0 0 24 24"); svg.setAttribute("aria-hidden", "true"); svg.classList.add("icon");
  const p = document.createElementNS("http://www.w3.org/2000/svg", "path");
  p.setAttribute("d", paths[name] || ""); svg.append(p);
  return svg;
}

// --- feedback -----------------------------------------------------------------
export function toast(msg, kind = "info") {
  const root = document.getElementById("toasts");
  const el = h(`div.toast.toast-${kind}`, { role: "status" }, msg);
  root.append(el);
  setTimeout(() => el.classList.add("show"), 10);
  setTimeout(() => { el.classList.remove("show"); setTimeout(() => el.remove(), 300); }, 3600);
}

export function errorMessage(err) {
  if (err instanceof ApiError) {
    if (err.code === "network_error") return t("err.network");
    if (err.status === 401) return t("err.session");
    return err.message && err.message !== err.code ? err.message : t("err.server");
  }
  return t("err.server");
}

export function showError(err) { toast(errorMessage(err), "error"); }

export function spinner() { return h("div.loading", { role: "status", "aria-live": "polite" }, h("span.spin"), t("common.loading")); }

export function errorBlock(err, retry) {
  return h("div.state-block", h("p", errorMessage(err)),
    retry && h("button.btn.btn-secondary", { on: { click: retry } }, t("common.retry")));
}

export function empty(text, action) { return h("div.state-block.empty", h("p", text), action || null); }

/** Render async content into a container with loading and error states. */
export async function load(container, fn) {
  clear(container).append(spinner());
  try {
    const node = await fn();
    clear(container).append(...[].concat(node).filter(Boolean));
  } catch (err) {
    clear(container).append(errorBlock(err, () => load(container, fn)));
  }
}

// --- dialogs ------------------------------------------------------------------
export function modal(title, body, actions) {
  return new Promise(resolve => {
    const root = document.getElementById("modal-root");
    const close = v => { overlay.remove(); document.body.classList.remove("modal-open"); resolve(v); };
    const overlay = h("div.modal-overlay", { on: { click: e => { if (e.target === overlay) close(null); } } },
      h("div.modal", { role: "dialog", "aria-modal": "true", "aria-label": title },
        h("h2.modal-title", title), h("div.modal-body", body),
        h("div.modal-actions", actions.map(a => h(`button.btn.${a.kind || "btn-secondary"}`,
          { type: "button", on: { click: () => close(a.value instanceof Function ? a.value() : a.value) } }, a.label)))));
    root.append(overlay);
    document.body.classList.add("modal-open");
    const first = overlay.querySelector("input,textarea,select,button");
    first && first.focus();
    overlay.addEventListener("keydown", e => { if (e.key === "Escape") close(null); });
  });
}

export function confirmDialog(title, text, okLabel = t("common.confirm"), danger = false) {
  return modal(title, h("p", text), [
    { label: t("common.cancel"), value: false },
    { label: okLabel, value: true, kind: danger ? "btn-danger" : "btn-primary" },
  ]);
}

export async function reasonDialog(title, required = true) {
  const ta = h("textarea.input", { rows: 4, maxlength: 2000, "aria-label": t("common.reason") });
  for (;;) {
    const v = await modal(title, [h("p.muted", t("admin.reason_required")), ta], [
      { label: t("common.cancel"), value: null },
      { label: t("common.confirm"), value: () => ta.value.trim(), kind: "btn-primary" },
    ]);
    if (v === null) return null;
    if (!required || v.length >= 5) return v;
    toast(t("admin.reason_required"), "error");
  }
}

// --- form controls ------------------------------------------------------------
export function field(label, control, hint, opts = {}) {
  const id = control.id || ("f" + Math.random().toString(36).slice(2, 8));
  control.id = id;
  return h("div.field" + (opts.inline ? ".field-inline" : ""),
    h("label", { for: id }, label, opts.optional ? h("span.opt", ` (${t("common.optional")})`) : null),
    control, hint ? h("small.hint", hint) : null, h("small.field-error", { "aria-live": "polite" }));
}

export function input(attrs = {}) { return h("input.input", { type: "text", ...attrs }); }

export function select(options, value, attrs = {}) {
  const s = h("select.input", attrs);
  for (const [v, label] of options) s.append(h("option", { value: v ?? "", selected: String(v ?? "") === String(value ?? "") }, label));
  return s;
}

export function checkbox(label, checked, attrs = {}) {
  const cb = h("input", { type: "checkbox", checked: !!checked, ...attrs });
  return { el: h("label.check", cb, h("span", label)), cb };
}

export function setFieldErrors(form, fields = []) {
  form.querySelectorAll(".field-error").forEach(e => { e.textContent = ""; });
  form.querySelectorAll(".invalid").forEach(e => e.classList.remove("invalid"));
  for (const f of fields) {
    const name = (f.loc || "").split(".").pop();
    const ctl = form.querySelector(`[name="${CSS.escape(name)}"]`);
    if (ctl) {
      ctl.classList.add("invalid");
      const err = ctl.closest(".field")?.querySelector(".field-error");
      if (err) err.textContent = f.msg;
    }
  }
}

/** Cascading Division → District → Upazila → Thana selects. */
export function geoPicker(initial = {}, { thana = true, upazila = true, required = false } = {}) {
  const value = { division_id: initial.division_id || null, district_id: initial.district_id || null,
    upazila_id: initial.upazila_id || null, thana_id: initial.thana_id || null };
  const labels = {};
  const mk = name => h("select.input", { name, required: required && (name === "division_id" || name === "district_id") });
  const sDiv = mk("division_id"), sDis = mk("district_id"), sUpa = mk("upazila_id"), sTha = mk("thana_id");
  async function fill(sel, url, query, current, key) {
    clear(sel).append(h("option", { value: "" }, t("common.select")));
    sel.disabled = !query;
    if (!query) return;
    const rows = await api.get(url, query === true ? undefined : query);
    for (const r of rows) sel.append(h("option", { value: r.id, selected: String(r.id) === String(current) }, nm(r)));
    sel.disabled = rows.length === 0;
    labels[key] = rows;
  }
  const label = (key, id) => nm((labels[key] || []).find(r => String(r.id) === String(id)));
  sDiv.addEventListener("change", async () => {
    value.division_id = +sDiv.value || null; value.district_id = value.upazila_id = value.thana_id = null;
    await fill(sDis, "/api/geo/districts", value.division_id && { division_id: value.division_id }, null, "dis");
    await fill(sUpa, "", null); await fill(sTha, "", null);
  });
  sDis.addEventListener("change", async () => {
    value.district_id = +sDis.value || null; value.upazila_id = value.thana_id = null;
    await fill(sUpa, "/api/geo/upazilas", value.district_id && { district_id: value.district_id }, null, "upa");
    await fill(sTha, "/api/geo/thanas", value.district_id && { district_id: value.district_id }, null, "tha");
  });
  sUpa.addEventListener("change", async () => {
    value.upazila_id = +sUpa.value || null; value.thana_id = null;
    await fill(sTha, "/api/geo/thanas", value.district_id && { district_id: value.district_id, upazila_id: value.upazila_id || undefined }, null, "tha");
  });
  sTha.addEventListener("change", () => { value.thana_id = +sTha.value || null; });
  const ready = (async () => {
    await fill(sDiv, "/api/geo/divisions", true, value.division_id, "div");
    await fill(sDis, "/api/geo/districts", value.division_id && { division_id: value.division_id }, value.district_id, "dis");
    await fill(sUpa, "/api/geo/upazilas", value.district_id && { district_id: value.district_id }, value.upazila_id, "upa");
    await fill(sTha, "/api/geo/thanas", value.district_id && { district_id: value.district_id }, value.thana_id, "tha");
  })().catch(() => {});
  const el = h("div.geo-grid",
    field(t("geo.division"), sDiv), field(t("geo.district"), sDis),
    upazila ? field(t("geo.upazila"), sUpa, null, { optional: true }) : null,
    thana ? field(t("geo.thana"), sTha, null, { optional: true }) : null);
  return { el, value, ready, label: () => label("upa", value.upazila_id) || label("dis", value.district_id) || label("div", value.division_id) };
}

// --- therapist presentation ---------------------------------------------------
export function avatar(url, name, size = "md") {
  if (url && url.startsWith("/api/")) url = null; // demo: photos are not stored
  if (url) return h(`img.avatar.avatar-${size}`, { src: url + (url.includes("?") ? "" : "?size=thumb"), alt: name || "", loading: "lazy" });
  const initials = (name || "?").split(/\s+/).filter(Boolean).slice(0, 2).map(w => w[0]).join("").toUpperCase();
  return h(`div.avatar.avatar-${size}.avatar-fallback`, { "aria-hidden": "true" }, initials);
}

export function verifiedBadge() { return h("span.badge.badge-verified", icon("shield"), t("card.verified")); }

export function codeChip(code) {
  if (!code) return null;
  const btn = h("button.code-chip", { type: "button", title: t("common.copy"), on: { click: async e => {
    e.stopPropagation();
    try { await navigator.clipboard.writeText(code); toast(t("common.copied")); } catch { toast(code); }
  } } }, h("span.code-label", t("profile.code") + ": "), h("strong", num(code)), icon("copy"));
  return btn;
}

export function primaryLocation(p) {
  const l = (p.locations || [])[0];
  if (!l) return "";
  return [l.workplace, nm(l, "thana") || nm(l, "upazila"), nm(l, "district")].filter(Boolean).join(", ");
}

export function statusPill(status, prefix = "status.") {
  return h(`span.pill.pill-${status}`, t(prefix + status));
}

export function pager(data, onPage) {
  const pages = Math.max(1, Math.ceil((data.total || 0) / (data.page_size || 20)));
  if (pages <= 1) return null;
  return h("nav.pager", { "aria-label": "pagination" },
    h("button.btn.btn-ghost", { disabled: data.page <= 1, on: { click: () => onPage(data.page - 1) } }, t("common.prev_page")),
    h("span", t("common.page_of", { page: data.page, pages })),
    h("button.btn.btn-ghost", { disabled: data.page >= pages, on: { click: () => onPage(data.page + 1) } }, t("common.next_page")));
}

export function fmt(iso, time) { return fmtDate(iso, time); }

export function isPatient() { return state.user && state.user.role === "patient"; }
