// In-memory session state. The session token itself lives only in an HttpOnly cookie.
export const state = {
  user: null,        // { id, role, phone, language, ... }
  csrf: null,
  config: null,      // /api/config/public
  savedIds: new Set(),
  pendingPhone: null,
  pendingRole: "patient",
};

const LS = {
  get(key, fallback) {
    try { const v = localStorage.getItem(key); return v === null ? fallback : JSON.parse(v); } catch { return fallback; }
  },
  set(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* private mode etc. */ }
  },
  remove(key) { try { localStorage.removeItem(key); } catch { /* ignore */ } },
};
export { LS };

// Device-only conveniences (never sent to the server unless used in a query).
export const prefs = {
  location() { return LS.get("chini.location", null); },   // { division_id, district_id, ..., label }
  setLocation(loc) { LS.set("chini.location", loc); },
  recent() { return LS.get("chini.recent", []); },
  addRecent(id) {
    const list = [id, ...LS.get("chini.recent", []).filter(x => x !== id)].slice(0, 8);
    LS.set("chini.recent", list);
  },
};
