// Patient-facing screens: home, search, location, therapist profile, My Therapists, profile, appointments.
import { api } from "../api.js";
import { fmtDate, getLang, nm, num, t } from "../i18n.js";
import { go } from "../router.js";
import { prefs, state } from "../state.js";
import {
  avatar, checkbox, clear, codeChip, confirmDialog, empty, field, geoPicker, h, icon, input, isPatient, load,
  modal, pager, primaryLocation, select, setFieldErrors, showError, statusPill, toast, verifiedBadge,
} from "../ui.js";
import { renderChrome, view } from "../app.js";
import { footerLinks } from "./common.js";

const page = (...c) => clear(view()).append(h("div.page", ...c));
const PROFS = ["PT", "OT", "SLT"];

// ---------------------------------------------------------------------------------
// Therapist card + actions
// ---------------------------------------------------------------------------------
export function therapistCard(p, { compact = false, onRemove } = {}) {
  const name = (getLang() === "bn" && p.name_bn) || p.name;
  const saveBtn = h("button.btn.btn-secondary.btn-sm", { type: "button" });
  const paintSave = () => {
    const saved = state.savedIds.has(p.id);
    clear(saveBtn).append(icon("heart"), saved ? t("card.saved") : t("card.save"));
    saveBtn.classList.toggle("is-saved", saved);
  };
  paintSave();
  saveBtn.addEventListener("click", async e => {
    e.stopPropagation();
    if (!isPatient()) { state.pendingRole = "patient"; state.returnTo = "/t/" + p.id; return go("/login"); }
    try {
      if (state.savedIds.has(p.id)) {
        await api.del(`/api/patient/saved/${p.id}`); state.savedIds.delete(p.id); toast(t("saved.removed"));
        onRemove && onRemove();
      } else {
        await api.post(`/api/patient/saved/${p.id}`); state.savedIds.add(p.id); toast(t("saved.added"));
      }
      paintSave();
    } catch (err) { showError(err); }
  });
  return h("article.tcard", { on: { click: e => { if (!e.target.closest("button,a")) go("/t/" + p.id); } } },
    h("div.tcard-head",
      avatar(p.photo_url, name),
      h("div.tcard-main",
        h("h3.tcard-name", name),
        h("p.tcard-prof", t("prof." + p.profession), p.designation ? ` · ${p.designation}` : ""),
        h("div.tcard-meta", p.verified ? verifiedBadge() : null, codeChip(p.chini_code)))),
    h("div.tcard-info",
      p.experience_years != null ? h("span", t("profile.experience_years", { n: p.experience_years })) : null,
      primaryLocation(p) ? h("span", icon("pin"), primaryLocation(p)) : null,
      p.distance_km != null ? h("span.dist", t("search.km", { km: p.distance_km })) : null,
      p.home_visit ? h("span.pill.pill-soft", t("card.home_visit")) : null),
    !compact && p.services?.length ? h("div.chips", p.services.slice(0, 3).map(s => h("span.chip", t("service." + s)))) : null,
    p.available === false ? h("p.alert.alert-warn", t("card.unavailable")) : null,
    h("div.tcard-actions",
      h("a.btn.btn-ghost.btn-sm", { href: "#/t/" + p.id }, t("card.view")),
      p.available === false ? null : saveBtn,
      p.phone ? callButton(p) : h("span.muted.small", t("card.no_phone"))));
}

export function callButton(p, big = false) {
  return h(`button.btn.btn-call${big ? ".btn-lg.btn-block" : ".btn-sm"}`, { type: "button", on: { click: e => {
    e.stopPropagation(); startCall(p);
  } } }, icon("phone"), t("card.call"));
}

async function startCall(p) {
  const name = (getLang() === "bn" && p.name_bn) || p.name;
  if (!isPatient()) {
    // Guests can call directly; nothing is recorded.
    const ok = await modal(t("call.title", { name }), [h("p", t("call.note")), h("p.muted", t("call.login_hint"))], [
      { label: t("common.cancel"), value: false }, { label: t("call.go"), value: true, kind: "btn-call" }]);
    if (ok) window.location.href = "tel:" + p.phone;
    return;
  }
  const share = checkbox(t("call.share"), false);
  const ok = await modal(t("call.title", { name }), [h("p", t("call.note")), share.el], [
    { label: t("common.cancel"), value: false }, { label: t("call.go"), value: true, kind: "btn-call" }]);
  if (!ok) return;
  try {
    const res = await api.post(`/api/patient/therapists/${p.id}/call`, { share_details: share.cb.checked });
    window.location.href = res.tel;
  } catch (err) {
    // If logging fails we still let the patient call — the record is optional.
    window.location.href = "tel:" + p.phone;
  }
}

function resultsList(data, onPage) {
  if (!data.items.length) return empty(t("search.none"), h("a.btn.btn-secondary", { href: "#/location" }, t("home.choose_location")));
  return [h("p.muted.small", t("common.results", { n: data.total })),
    h("div.cards", data.items.map(p => therapistCard(p))), pager(data, onPage)];
}

// ---------------------------------------------------------------------------------
// Home
// ---------------------------------------------------------------------------------
export function home() {
  const loc = prefs.location();
  const q = input({ type: "search", placeholder: t("home.search_ph"), "aria-label": t("common.search"), maxlength: 80 });
  const searchForm = h("form.searchbar", { role: "search", on: { submit: e => {
    e.preventDefault(); go("/search?q=" + encodeURIComponent(q.value.trim()));
  } } }, icon("search"), q, h("button.btn.btn-primary.btn-sm", { type: "submit" }, t("common.search")));

  const nearby = h("div");
  const recent = h("div");
  page(
    searchForm,
    h("a.location-chip", { href: "#/location" }, icon("pin"),
      loc ? (loc.gps ? t("geo.gps_using") : loc.label) : t("home.choose_location")),
    h("h2.section-title", t("home.categories")),
    h("div.categories", PROFS.map(p => h("a.cat-card.cat-" + p.toLowerCase(), { href: "#/search?profession=" + p },
      h("span.cat-abbr", p), h("span.cat-name", t("prof." + p)), h("span.cat-desc", t("prof." + p + ".desc"))))),
    h("h2.section-title", loc && !loc.gps ? t("home.in_area", { area: loc.label }) : t("home.nearby")),
    nearby,
    recent,
    h("a.verify-link", { href: "#/verification" }, icon("shield"), t("home.learn_verify")),
    footerLinks());

  if (!loc) {
    nearby.append(h("div.state-block.empty", h("p", t("home.set_location_hint")),
      h("a.btn.btn-secondary", { href: "#/location" }, t("home.choose_location"))));
  } else {
    load(nearby, async () => {
      const data = await api.get("/api/public/therapists", { ...locationQuery(loc), page_size: 5 });
      if (!data.items.length) return empty(t("search.none"));
      return [h("div.cards", data.items.map(p => therapistCard(p, { compact: true }))),
        h("a.btn.btn-ghost.btn-block", { href: "#/search?" + new URLSearchParams(locationQuery(loc)) }, t("common.view_all"))];
    });
  }
  const ids = prefs.recent().slice(0, 4);
  if (ids.length) {
    load(recent, async () => {
      const items = (await Promise.all(ids.map(id => api.get(`/api/public/therapists/${id}`).catch(() => null)))).filter(Boolean);
      if (!items.length) return null;
      return [h("h2.section-title", t("home.recent")), h("div.hscroll", items.map(p => miniCard(p)))];
    });
  }
}

function miniCard(p) {
  return h("a.mini-card", { href: "#/t/" + p.id }, avatar(p.photo_url, p.name, "sm"),
    h("span.mini-name", (getLang() === "bn" && p.name_bn) || p.name), h("span.muted.small", t("prof." + p.profession + ".short")));
}

function locationQuery(loc) {
  if (!loc) return {};
  if (loc.gps) return { lat: loc.lat, lng: loc.lng, radius_km: 25, sort: "distance" };
  const q = {};
  for (const k of ["division_id", "district_id", "upazila_id", "thana_id"]) if (loc[k]) q[k] = loc[k];
  return q;
}

// ---------------------------------------------------------------------------------
// Location filter
// ---------------------------------------------------------------------------------
export function locationScreen() {
  const current = prefs.location() || {};
  const geo = geoPicker(current.gps ? {} : current);
  const status = h("p.muted.small");
  page(h("div.card.form",
    h("h1.h2", t("geo.location_title")),
    h("button.btn.btn-secondary.btn-block", { type: "button", on: { click: () => {
      if (!navigator.geolocation) { status.textContent = t("geo.gps_denied"); return; }
      navigator.geolocation.getCurrentPosition(pos => {
        // Only real device coordinates are used; nothing is guessed.
        prefs.setLocation({ gps: true, lat: +pos.coords.latitude.toFixed(4), lng: +pos.coords.longitude.toFixed(4) });
        go("/home");
      }, () => { status.textContent = t("geo.gps_denied"); }, { enableHighAccuracy: false, timeout: 15000, maximumAge: 600000 });
    } } }, icon("pin"), t("geo.use_gps")),
    h("p.muted.small", t("geo.gps_note")), status,
    h("hr"),
    geo.el,
    h("button.btn.btn-primary.btn-block", { type: "button", on: { click: () => {
      if (!geo.value.division_id) { toast(t("home.set_location_hint"), "error"); return; }
      prefs.setLocation({ ...geo.value, label: geo.label() });
      go("/home");
    } } }, t("geo.apply"))));
}

// ---------------------------------------------------------------------------------
// Search
// ---------------------------------------------------------------------------------
export function search({ query }) {
  const loc = prefs.location();
  const f = {
    q: query.get("q") || "", profession: query.get("profession") || "", service: query.get("service") || "",
    min_experience: query.get("min_experience") || "", home_visit: query.get("home_visit") === "true",
    sort: query.get("sort") || "relevance",
    division_id: query.get("division_id") || "", district_id: query.get("district_id") || "",
    upazila_id: query.get("upazila_id") || "", thana_id: query.get("thana_id") || "", area: query.get("area") || "",
    lat: query.get("lat") || "", lng: query.get("lng") || "", radius_km: query.get("radius_km") || "",
  };
  if (!query.has("division_id") && !query.has("lat") && loc) Object.assign(f, Object.fromEntries(Object.entries(locationQuery(loc)).map(([k, v]) => [k, String(v)])));

  const q = input({ type: "search", name: "q", value: f.q, placeholder: t("home.search_ph"), maxlength: 80 });
  const prof = select([["", t("search.any")], ...PROFS.map(p => [p, t("prof." + p)])], f.profession, { name: "profession" });
  const services = () => [["", t("search.any")], ...(f.profession ? state.config?.services?.[f.profession] || []
    : Object.values(state.config?.services || {}).flat()).map(s => [s, t("service." + s)])];
  const svc = select(services(), f.service, { name: "service" });
  prof.addEventListener("change", () => { f.profession = prof.value; const n = select(services(), "", { name: "service" }); svc.replaceWith(n); });
  const exp = select([["", t("search.any")], ...[1, 3, 5, 10].map(n => [n, "≥ " + t("common.years", { n })])], f.min_experience, { name: "min_experience" });
  const hv = checkbox(t("search.home_visit"), f.home_visit);
  const sort = select([["relevance", t("search.sort.relevance")], ["experience", t("search.sort.experience")],
    ["name", t("search.sort.name")], ...(f.lat ? [["distance", t("search.sort.distance")]] : [])], f.sort, { name: "sort" });
  const geo = geoPicker(f.lat ? {} : f);
  const area = input({ name: "area", value: f.area, maxlength: 60 });

  const results = h("div");
  const filters = h("details.filters", { open: !!(f.profession || f.service || f.min_experience || f.home_visit) },
    h("summary", t("search.filters")),
    h("div.filter-grid",
      field(t("search.profession"), prof), field(t("search.service"), svc),
      field(t("search.min_exp"), exp), field(t("search.sort"), sort)),
    f.lat ? h("p.muted.small", icon("pin"), t("geo.gps_using")) : [geo.el, field(t("geo.area"), area, null, { optional: true })],
    hv.el,
    h("button.btn.btn-primary.btn-block", { type: "button", on: { click: () => apply() } }, t("search.apply")));

  function apply(pageNo = 1) {
    const params = {
      q: q.value.trim(), profession: prof.value, service: view().querySelector('[name="service"]')?.value || "",
      min_experience: exp.value, home_visit: hv.cb.checked ? "true" : "", sort: sort.value,
      ...(f.lat ? { lat: f.lat, lng: f.lng, radius_km: f.radius_km || 25 }
        : { division_id: geo.value.division_id || "", district_id: geo.value.district_id || "",
            upazila_id: geo.value.upazila_id || "", thana_id: geo.value.thana_id || "", area: area.value.trim() }),
    };
    const clean = Object.fromEntries(Object.entries(params).filter(([, v]) => v !== "" && v !== null && v !== undefined));
    history.replaceState(null, "", "#/search?" + new URLSearchParams(clean));
    run(clean, pageNo);
  }
  function run(params, pageNo) {
    load(results, async () => {
      const data = await api.get("/api/public/therapists", { ...params, page: pageNo, page_size: 20 });
      return resultsList(data, p => run(params, p));
    });
  }
  page(
    h("h1.h2", f.profession ? t("prof." + f.profession) : t("search.title")),
    h("form.searchbar", { role: "search", on: { submit: e => { e.preventDefault(); apply(); } } },
      icon("search"), q, h("button.btn.btn-primary.btn-sm", { type: "submit" }, t("common.search"))),
    filters, results);
  const initial = Object.fromEntries(Object.entries(f).filter(([k, v]) => v && v !== false && k !== "home_visit"));
  if (f.home_visit) initial.home_visit = "true";
  run(initial, 1);
}

// ---------------------------------------------------------------------------------
// Therapist public profile
// ---------------------------------------------------------------------------------
export function therapistProfile({ params }) {
  const id = +params.id;
  const box = h("div");
  page(box);
  load(box, async () => {
    const p = await api.get(`/api/public/therapists/${id}`);
    prefs.addRecent(id);
    const name = (getLang() === "bn" && p.name_bn) || p.name;
    const bio = (getLang() === "bn" && p.bio_bn) || p.bio || p.bio_bn;
    const saveBtn = therapistCard(p).querySelector(".tcard-actions .btn-secondary");
    return [
      h("a.back-link", { href: "#/home", on: { click: e => { e.preventDefault(); history.back(); } } }, icon("back"), t("common.back")),
      h("section.profile-head.card",
        avatar(p.photo_url ? p.photo_url + "?size=full" : null, name, "lg"),
        h("h1.h2", name), p.name_bn && getLang() !== "bn" ? h("p.muted", p.name_bn) : null,
        h("p.tcard-prof", t("prof." + p.profession), p.designation ? ` · ${p.designation}` : ""),
        verifiedBadge(),
        h("div.code-big", h("span", t("profile.code") + ":"), h("strong", num(p.chini_code)), codeChip(p.chini_code)),
        h("p.small.muted.verify-note", t("profile.verified_note"), " ", h("a", { href: "#/verification" }, t("home.learn_verify")))),
      h("div.action-bar",
        p.phone ? callButton(p, true) : h("p.muted", t("card.no_phone")),
        saveBtn,
        state.config?.appointments_enabled ? h("a.btn.btn-ghost.btn-block", { href: `#/appointments/new/${p.id}`,
          on: { click: e => { if (!isPatient()) { e.preventDefault(); state.returnTo = `/appointments/new/${p.id}`; state.pendingRole = "patient"; go("/login"); } } } },
          t("profile.request")) : null),
      h("section.card",
        h("h2.h3", t("profile.experience")), h("p", t("profile.experience_years", { n: p.experience_years ?? 0 })),
        p.home_visit ? h("p", h("span.pill.pill-soft", t("card.home_visit"))) : null,
        bio ? [h("h2.h3", t("profile.about")), h("p.pre", bio)] : null),
      p.qualifications?.length ? h("section.card", h("h2.h3", t("profile.qualifications")),
        h("ul.plain", p.qualifications.map(q => h("li", h("strong", q.degree), " — ", q.institution,
          q.passing_year ? ` (${num(q.passing_year)})` : "")))) : null,
      p.services?.length ? h("section.card", h("h2.h3", t("profile.services")),
        h("div.chips", p.services.map(s => h("span.chip", t("service." + s))))) : null,
      h("section.card", h("h2.h3", t("profile.practice")),
        p.locations.map(l => h("div.loc",
          h("strong", l.workplace),
          h("p", [l.address_line, l.area, nm(l, "thana"), nm(l, "upazila"), nm(l, "district"), nm(l, "division")].filter(Boolean).join(", ")),
          l.working_hours ? h("p.muted", t("profile.hours") + ": " + l.working_hours) : null))),
      isPatient() ? h("button.link.danger-link", { type: "button", on: { click: () => report(p.id) } }, t("profile.report")) : null,
    ];
  });
}

async function report(tid) {
  const reasons = ["fake_credentials", "wrong_information", "misconduct", "other"];
  const sel = select(reasons.map(r => [r, t("report.reason." + r)]), reasons[0]);
  const det = h("textarea.input", { rows: 3, maxlength: 1000 });
  const ok = await modal(t("report.title"), [field(t("common.reason"), sel), field(t("common.details"), det, null, { optional: true })],
    [{ label: t("common.cancel"), value: false }, { label: t("common.submit"), value: true, kind: "btn-danger" }]);
  if (!ok) return;
  try { await api.post(`/api/patient/therapists/${tid}/report`, { reason: sel.value, details: det.value.trim() || null }); toast(t("report.sent")); }
  catch (err) { showError(err); }
}

// ---------------------------------------------------------------------------------
// My Therapists
// ---------------------------------------------------------------------------------
export function myTherapists() {
  if (!isPatient()) {
    return page(h("h1.h2", t("saved.title")), empty(t("call.login_hint"),
      h("a.btn.btn-primary", { href: "#/login", on: { click: () => { state.pendingRole = "patient"; state.returnTo = "/my-therapists"; } } }, t("common.login"))));
  }
  const box = h("div");
  const show = (p = 1) => load(box, async () => {
    const data = await api.get("/api/patient/saved", { page: p, page_size: 20 });
    if (!data.items.length) return empty(t("saved.empty"), h("a.btn.btn-primary", { href: "#/search" }, t("landing.find")));
    return [h("div.cards", data.items.map(item => therapistCard(item, { onRemove: () => show(p) }))), pager(data, show)];
  });
  page(h("h1.h2", t("saved.title")), h("p.alert.alert-info", t("saved.note")), box,
    state.config?.appointments_enabled ? h("a.btn.btn-ghost.btn-block", { href: "#/appointments" }, t("patient.appointments")) : null);
  show();
}

// ---------------------------------------------------------------------------------
// Patient profile (create / view / edit)
// ---------------------------------------------------------------------------------
function profileForm(existing, onSaved, submitLabel) {
  const v = existing || {};
  const name = input({ name: "full_name", value: v.full_name || "", required: true, maxlength: 120, autocomplete: "name" });
  const email = input({ name: "email", type: "email", value: v.email || "", maxlength: 200, autocomplete: "email" });
  const house = input({ name: "house_no", value: v.house_no || "", maxlength: 50 });
  const roadNo = input({ name: "road_no", value: v.road_no || "", maxlength: 50 });
  const roadName = input({ name: "road_name", value: v.road_name || "", maxlength: 120 });
  const geo = geoPicker(v);
  const langSel = select([["bn", "বাংলা"], ["en", "English"]], v.language || getLang(), { name: "language" });
  const btn = h("button.btn.btn-primary.btn-block", { type: "submit" }, submitLabel);
  const form = h("form.form", { novalidate: true, on: { submit: async e => {
    e.preventDefault();
    btn.disabled = true;
    try {
      const saved = await api.put("/api/patient/profile", {
        full_name: name.value, email: email.value.trim() || null, house_no: house.value.trim() || null,
        road_no: roadNo.value.trim() || null, road_name: roadName.value.trim() || null, ...geo.value, language: langSel.value,
      });
      if (langSel.value !== getLang()) { (await import("../i18n.js")).setLang(langSel.value); renderChrome(); }
      toast(t("common.saved"));
      onSaved(saved);
    } catch (err) { setFieldErrors(form, err.details?.fields); showError(err); }
    finally { btn.disabled = false; }
  } } },
    field(t("patient.full_name"), name),
    field(t("patient.email"), email, null, { optional: true }),
    h("fieldset", h("legend", t("patient.address")),
      h("div.grid-3", field(t("patient.house_no"), house), field(t("patient.road_no"), roadNo), field(t("patient.road_name"), roadName)),
      geo.el),
    field(t("patient.language"), langSel), btn);
  return form;
}

export function onboarding() {
  page(h("div.card", h("h1.h2", t("onboard.title")), h("p.muted", t("onboard.lead")),
    profileForm(null, () => { state.user.has_profile = true; go(state.returnTo || "/home", true); }, t("common.continue"))));
}

export function profile() {
  const box = h("div");
  page(box);
  load(box, async () => {
    let prof;
    try { prof = await api.get("/api/patient/profile"); }
    catch (err) { if (err.status === 404) { go("/onboarding", true); return null; } throw err; }
    const sharing = h("div");
    load(sharing, async () => {
      const rows = await api.get("/api/patient/sharing");
      if (!rows.length) return h("p.muted", t("patient.sharing_none"));
      return h("ul.list", rows.map(r => h("li.list-item.row-between",
        h("span", h("strong", r.display_name), " · ", t("prof." + r.profession + ".short"), " · ", num(r.chini_code)),
        h("button.btn.btn-ghost.btn-sm", { type: "button", on: { click: async () => {
          try { await api.del(`/api/patient/sharing/${r.therapist_id}`); load(sharing, async () => h("p.muted", t("common.saved"))); profile(); }
          catch (err) { showError(err); }
        } } }, t("patient.stop_sharing")))));
    });
    const history = h("div");
    load(history, async () => {
      const data = await api.get("/api/patient/contacts", { page_size: 10 });
      if (!data.items.length) return h("p.muted", t("common.none"));
      return h("ul.list", data.items.map(c => h("li.list-item", h("a", { href: "#/t/" + c.therapist_id }, c.display_name),
        " · ", t("card.call"), " · ", h("small.muted", fmtDate(c.created_at, true)))));
    });
    return [
      h("h1.h2", t("patient.profile")),
      h("section.card", h("p.muted", t("patient.verified_phone")), h("p.phone-display", icon("check"), prof.phone_e164),
        profileForm(prof, () => profile(), t("common.save"))),
      h("section.card", h("h2.h3", t("patient.sharing")), sharing),
      h("section.card", h("h2.h3", t("patient.history")), h("p.muted.small", t("saved.note")), history),
      state.config?.appointments_enabled ? h("a.btn.btn-secondary.btn-block", { href: "#/appointments" }, t("patient.appointments")) : null,
      h("button.btn.btn-ghost.btn-block", { type: "button", on: { click: logout } }, t("common.logout")),
      h("a.link.danger-link.center", { href: "#/account/delete" }, t("patient.delete_account")),
      footerLinks(),
    ];
  });
}

export async function logout() {
  try { await api.post("/api/auth/logout"); } catch { /* session may already be gone */ }
  state.user = null; state.csrf = null; state.savedIds = new Set();
  renderChrome(); go("/home", true);
}

// ---------------------------------------------------------------------------------
// Appointments
// ---------------------------------------------------------------------------------
export function appointments() {
  const box = h("div");
  const show = (p = 1) => load(box, async () => {
    const data = await api.get("/api/patient/appointments", { page: p });
    if (!data.items.length) return empty(t("appt.empty"));
    return [h("ul.list", data.items.map(a => h("li.list-item.appt",
      h("div.row-between", h("a", { href: "#/t/" + a.therapist_id }, h("strong", a.therapist_name)), statusPill(a.status, "appt.status.")),
      h("p.small", fmtDate(a.preferred_date), " · ", t("appt.time." + a.preferred_time),
        a.service_code ? " · " + t("service." + a.service_code) : ""),
      a.therapist_response ? h("p.small", h("em", t("appt.response") + ": "), a.therapist_response) : null,
      ["requested", "accepted"].includes(a.status) ? h("button.btn.btn-ghost.btn-sm", { type: "button", on: { click: async () => {
        if (!(await confirmDialog(t("appt.cancel"), t("admin.confirm_action")))) return;
        try { await api.post(`/api/patient/appointments/${a.id}/cancel`); show(p); } catch (err) { showError(err); }
      } } }, t("appt.cancel")) : null))), pager(data, show)];
  });
  page(h("h1.h2", t("patient.appointments")), box);
  show();
}

export function newAppointment({ params }) {
  const tid = +params.id;
  const box = h("div");
  page(box);
  load(box, async () => {
    const p = await api.get(`/api/public/therapists/${tid}`);
    const tomorrow = new Date(Date.now() + 86400000).toISOString().slice(0, 10);
    const max = new Date(Date.now() + 89 * 86400000).toISOString().slice(0, 10);
    const svc = select([["", t("search.any")], ...p.services.map(s => [s, t("service." + s)])], "", { name: "service_code" });
    const date = input({ type: "date", name: "preferred_date", min: tomorrow, max, value: tomorrow, required: true });
    const time = select(["morning", "afternoon", "evening"].map(x => [x, t("appt.time." + x)]), "morning", { name: "preferred_time" });
    const msg = h("textarea.input", { name: "message", rows: 3, maxlength: 500 });
    const btn = h("button.btn.btn-primary.btn-block", { type: "submit" }, t("appt.send"));
    const form = h("form.card.form", { on: { submit: async e => {
      e.preventDefault(); btn.disabled = true;
      try {
        await api.post("/api/patient/appointments", { therapist_id: tid, service_code: svc.value || null,
          preferred_date: date.value, preferred_time: time.value, message: msg.value.trim() || null });
        toast(t("appt.sent")); go("/appointments", true);
      } catch (err) {
        if (err.code === "profile_required") { state.returnTo = `/appointments/new/${tid}`; go("/onboarding"); return; }
        setFieldErrors(form, err.details?.fields); showError(err);
      } finally { btn.disabled = false; }
    } } },
      h("h1.h2", t("appt.title")), h("p", h("strong", p.name), " · ", t("prof." + p.profession)),
      field(t("appt.service"), svc, null, { optional: true }), field(t("appt.date"), date), field(t("appt.time"), time),
      field(t("appt.message"), msg, null, { optional: true }),
      h("p.alert.alert-info", t("appt.consent")), btn);
    return form;
  });
}
