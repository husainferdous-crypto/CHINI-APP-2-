// In-browser demo backend for CHINI. Mirrors the real API's rules closely enough to try every screen.
// Data lives only in this browser (localStorage). Nothing is sent anywhere. All people are fictional.
import GEO from "./geo-data.js";
import { ApiError } from "./api.js";

const KEY = "chini.demo.db.v1";
const OTP = "123456";
const SERVICES = {
  PT: ["pt_musculoskeletal", "pt_neuro", "pt_pediatric", "pt_sports", "pt_geriatric", "pt_cardiopulmonary", "pt_post_surgery", "pt_pain"],
  OT: ["ot_pediatric", "ot_sensory", "ot_adl", "ot_hand", "ot_neuro", "ot_mental_health", "ot_autism"],
  SLT: ["slt_speech_delay", "slt_stuttering", "slt_voice", "slt_swallowing", "slt_language", "slt_autism", "slt_aphasia"],
};
const CRITICAL = ["personal.full_name", "personal.full_name_bn", "personal.date_of_birth", "personal.nid_number", "personal.photo_key",
  "education.qualifications", "education.registration_body", "education.registration_number", "education.internship_completed",
  "practice.profession", "practice.experience_years"];
const REQUIRED_DOCS = ["national_id", "degree_certificate"];

const err = (status, code, message, details) => { throw new ApiError(status, code, message, details); };
const now = () => new Date().toISOString();
const clone = o => JSON.parse(JSON.stringify(o));
const byId = (list, id) => list.find(x => x.id === +id);

// ---------------------------------------------------------------- storage
let db = null;
function load() {
  if (db) return db;
  try { db = JSON.parse(localStorage.getItem(KEY) || "null"); } catch { db = null; }
  if (!db) { db = seed(); save(); }
  return db;
}
function save() { try { localStorage.setItem(KEY, JSON.stringify(db)); } catch { /* storage full or blocked */ } }
const nextId = () => ++db.seq;

// ---------------------------------------------------------------- seed (synthetic)
function seed() {
  db = { seq: 100, users: [], patients: {}, therapists: {}, codes: {}, saved: [], links: [], contacts: [], appts: [],
    notifs: [], reports: [], audit: [], session: null,
    settings: { minor_changes_require_review: false, chini_code_warning_ratio: 0.8, chini_code_blocklist: ["0000", "1111", "1234", "9999"], appointments_enabled: true } };
  const first = ["Ayesha", "Rahim", "Nusrat", "Tanvir", "Farzana", "Sabbir", "Mitu", "Arif", "Sadia", "Imran", "Rumana", "Fahim", "Tania", "Jahid", "Shirin", "Rakib", "Lamia", "Sohel", "Nadia", "Kamrul"];
  const firstBn = ["আয়েশা", "রহিম", "নুসরাত", "তানভীর", "ফারজানা", "সাব্বির", "মিতু", "আরিফ", "সাদিয়া", "ইমরান", "রুমানা", "ফাহিম", "তানিয়া", "জাহিদ", "শিরিন", "রাকিব", "লামিয়া", "সোহেল", "নাদিয়া", "কামরুল"];
  const last = ["Akter", "Hossain", "Islam", "Rahman", "Chowdhury", "Sarker", "Khan", "Ahmed"];
  const lastBn = ["আক্তার", "হোসেন", "ইসলাম", "রহমান", "চৌধুরী", "সরকার", "খান", "আহমেদ"];
  const places = [["Dhaka", 23.78, 90.40], ["Gazipur", 24.0, 90.42], ["Narayanganj", 23.62, 90.5], ["Chattogram", 22.35, 91.82],
    ["Sylhet", 24.9, 91.87], ["Rajshahi", 24.37, 88.6], ["Khulna", 22.82, 89.55]];
  const work = ["CRP Savar", "City Rehab Centre", "Sunrise Therapy Clinic", "Green Life Hospital", "Model Physio Centre", "Speech Care BD", "Child Development Unit"];
  const degree = { PT: "BSc in Physiotherapy", OT: "BSc in Occupational Therapy", SLT: "BSc in Speech and Language Therapy" };
  db.users.push({ id: 1, phone: null, role: "admin", status: "active", language: "en", created_at: now(), email: "admin@chini.local", name: "Demo Admin", admin_role: "super_admin" });
  for (let i = 0; i < 30; i++) {
    const id = 1000 + i, prof = ["PT", "OT", "SLT"][i % 3];
    const [dname, lat, lng] = places[i % places.length];
    const dist = GEO.districts.find(d => d.name_en === dname);
    const up = GEO.upazilas.find(u => u.district_id === dist.id);
    const phone = `+88017${String(10000000 + i).padStart(8, "0")}`;
    db.users.push({ id, phone, role: "therapist", status: "active", language: "bn", created_at: now() });
    const data = {
      personal: { full_name: `${first[i % 20]} ${last[i % 8]}`, full_name_bn: `${firstBn[i % 20]} ${lastBn[i % 8]}`, date_of_birth: "1990-01-01",
        gender: "prefer_not", nid_number: String(1000000000 + i), email: null, public_phone: phone, show_phone_public: true, photo_key: "demo" },
      education: { qualifications: [{ degree: degree[prof], institution: "Bangladesh Health Professions Institute", passing_year: 2008 + (i % 14), result: null, show_public: true }],
        registration_body: null, registration_number: null, internship_completed: true },
      practice: { profession: prof, designation: ["Consultant", "Senior Therapist", "Clinical Therapist"][i % 3], experience_years: 2 + (i * 7) % 18,
        bio: "Fictional demo profile used to show how CHINI works.", bio_bn: "চিনি কীভাবে কাজ করে তা দেখানোর জন্য একটি কাল্পনিক ডেমো প্রোফাইল।",
        home_visit: i % 4 === 0, services: SERVICES[prof].filter((_, k) => (k + i) % 3 === 0).slice(0, 3),
        locations: [{ workplace: work[i % work.length], address_line: `Road ${(i % 20) + 1}`, area: null, division_id: dist.division_id, district_id: dist.id,
          upazila_id: up ? up.id : null, thana_id: null, latitude: +(lat + ((i * 37) % 15 - 7) / 100).toFixed(4), longitude: +(lng + ((i * 53) % 15 - 7) / 100).toFixed(4),
          working_hours: "Sat–Thu 10:00–18:00", is_primary: true }] },
      declaration: { accepted: true },
    };
    const code = String(1000 + ((i * 3797) % 9000)).padStart(4, "0");
    db.codes[code] = { status: "active", therapist_id: id, at: now(), note: null };
    db.therapists[id] = { status: "approved", published: true, chini_code: code, current_step: 5, draft: null, pending: null, approved: data,
      versions: [{ id: id * 10 + 1, no: 1, status: "approved", data, at: now(), note: "demo" }], approved_version_id: id * 10 + 1,
      documents: [{ id: id * 10 + 2, doc_type: "national_id", original_name: "nid.pdf", mime_type: "application/pdf", size_bytes: 120000, uploaded_at: now() }],
      reviews: [{ decision: "approved", reason: null, created_at: now(), reviewer_name: "Demo Admin", version_id: id * 10 + 1 }], approved_at: now(), submitted_at: now(), updated_at: now() };
  }
  // One applicant waiting in the admin queue.
  const aid = 2000;
  db.users.push({ id: aid, phone: "+8801999000001", role: "therapist", status: "active", language: "bn", created_at: now() });
  const appData = clone(db.therapists[1000].approved);
  appData.personal.full_name = "Sharmin Nahar"; appData.personal.full_name_bn = "শারমিন নাহার"; appData.personal.public_phone = "+8801999000001";
  db.therapists[aid] = { status: "submitted", published: false, chini_code: null, current_step: 5, draft: null,
    pending: { id: 20001, data: appData, submitted_at: now() }, approved: null, versions: [{ id: 20001, no: 1, status: "pending", data: appData, at: now() }],
    approved_version_id: null, documents: [
      { id: 20002, doc_type: "national_id", original_name: "nid-front.jpg", mime_type: "image/jpeg", size_bytes: 210000, uploaded_at: now() },
      { id: 20003, doc_type: "degree_certificate", original_name: "bsc-certificate.pdf", mime_type: "application/pdf", size_bytes: 480000, uploaded_at: now() }],
    reviews: [], submitted_at: now(), updated_at: now() };
  return db;
}

// ---------------------------------------------------------------- helpers
function normPhone(raw) {
  let s = String(raw || "").replace(/[০-৯]/g, d => "০১২৩৪৫৬৭৮৯".indexOf(d)).replace(/[\s\-().]/g, "");
  if (s.startsWith("+")) s = s.slice(1); else if (s.startsWith("00")) s = s.slice(2);
  if (!/^\d+$/.test(s)) return null;
  let n = s.startsWith("880") ? s.slice(3) : s.startsWith("0") ? s.slice(1) : s;
  return /^1[3-9]\d{8}$/.test(n) ? "+880" + n : null;
}
const me = () => (db.session ? db.users.find(u => u.id === db.session) : null);
function need(role) {
  const u = me();
  if (!u) err(401, "not_authenticated", "Please log in.");
  if (role && role !== "any" && u.role !== role) err(403, "forbidden", "You do not have access to this.");
  return u;
}
const page = (items, q, size = 20) => {
  const p = Math.max(1, +q.page || 1), ps = Math.min(+q.page_size || size, 100);
  return { items: items.slice((p - 1) * ps, p * ps), total: items.length, page: p, page_size: ps };
};
const geoName = (list, id) => list.find(x => x.id === id);
function notify(uid, type, payload = {}) { db.notifs.push({ id: nextId(), user_id: uid, type, payload, created_at: now(), read_at: null }); }
const admins = () => db.users.filter(u => u.role === "admin");
function audit(actor, action, target, extra = {}) {
  db.audit.unshift({ id: nextId(), actor_user_id: actor?.id, actor_name: actor?.name || actor?.role, actor_role: actor?.role, action,
    target_type: "therapist", target_id: String(target), created_at: now(), ...extra });
}
const tname = id => db.therapists[id]?.approved?.personal?.full_name || (db.therapists[id]?.pending || db.therapists[id]?.draft)?.data?.personal?.full_name;
const empty = () => ({ personal: { show_phone_public: false }, education: { qualifications: [] }, practice: { home_visit: false, services: [], locations: [] }, declaration: { accepted: false } });

function shape(id, full) {
  const t = db.therapists[id], d = t.approved, p = d.personal, pr = d.practice;
  const out = { id, name: p.full_name, name_bn: p.full_name_bn, profession: pr.profession, designation: pr.designation,
    experience_years: pr.experience_years, chini_code: t.chini_code, verified: true, home_visit: !!pr.home_visit,
    phone: p.show_phone_public ? p.public_phone : null, photo_url: null, services: pr.services || [],
    locations: (pr.locations || []).map(l => {
      const dis = geoName(GEO.districts, l.district_id), dv = geoName(GEO.divisions, l.division_id),
        up = geoName(GEO.upazilas, l.upazila_id), th = geoName(GEO.thanas, l.thana_id);
      return { workplace: l.workplace, address_line: l.address_line, area: l.area, working_hours: l.working_hours, is_primary: !!l.is_primary,
        latitude: l.latitude, longitude: l.longitude, district_en: dis?.name_en, district_bn: dis?.name_bn, division_en: dv?.name_en,
        division_bn: dv?.name_bn, upazila_en: up?.name_en, upazila_bn: up?.name_bn, thana_en: th?.name_en, thana_bn: th?.name_bn };
    }) };
  if (full) {
    out.bio = pr.bio; out.bio_bn = pr.bio_bn;
    out.qualifications = (d.education.qualifications || []).filter(q => q.show_public).map(q => ({ degree: q.degree, institution: q.institution, passing_year: q.passing_year }));
  }
  return out;
}
const isPublic = id => { const t = db.therapists[id]; const u = byId(db.users, id); return t && t.status === "approved" && t.published && u?.status === "active"; };

function flatten(data) { const o = {}; for (const [s, v] of Object.entries(data || {})) for (const [k, x] of Object.entries(v || {})) o[`${s}.${k}`] = x; return o; }
function diff(a, b) {
  const A = flatten(a), B = flatten(b), keys = [...new Set([...Object.keys(A), ...Object.keys(B)])].sort();
  return keys.filter(k => JSON.stringify(A[k] ?? null) !== JSON.stringify(B[k] ?? null))
    .map(k => ({ field: k, old: A[k] ?? null, new: B[k] ?? null, critical: CRITICAL.includes(k) }));
}
function missing(t, data) {
  const m = [], p = data.personal || {}, e = data.education || {}, pr = data.practice || {};
  for (const f of ["full_name", "date_of_birth", "nid_number", "photo_key"]) if (!p[f]) m.push("personal." + f);
  if (p.show_phone_public && !p.public_phone) m.push("personal.public_phone");
  if (!(e.qualifications || []).length) m.push("education.qualifications");
  if (!pr.profession) m.push("practice.profession");
  if (pr.experience_years === null || pr.experience_years === undefined) m.push("practice.experience_years");
  if (!(pr.locations || []).length) m.push("practice.locations");
  const have = new Set(t.documents.map(d => d.doc_type));
  for (const d of REQUIRED_DOCS) if (!have.has(d)) m.push("documents." + d);
  if (!data.declaration?.accepted) m.push("declaration.accepted");
  return m;
}
function assignCode(t, tid) {
  if (t.chini_code) { db.codes[t.chini_code].status = "active"; return t.chini_code; }
  const block = new Set(db.settings.chini_code_blocklist);
  const free = []; for (let i = 0; i < 10000; i++) { const c = String(i).padStart(4, "0"); if (!db.codes[c] && !block.has(c)) free.push(c); }
  if (!free.length) err(503, "chini_codes_exhausted", "All four-digit CHINI codes are in use.");
  const code = free[Math.floor(Math.random() * free.length)];
  db.codes[code] = { status: "active", therapist_id: tid, at: now(), note: null };
  t.chini_code = code;
  return code;
}
function codeUsage() {
  const v = Object.values(db.codes), c = s => v.filter(x => x.status === s).length;
  return { active: c("active"), reserved: c("reserved"), retired: c("retired"), used: v.length, capacity: 10000, available: 10000 - v.length - db.settings.chini_code_blocklist.length };
}
function userOut(u) {
  const o = { id: u.id, role: u.role, phone: u.phone, language: u.language, unread_notifications: db.notifs.filter(n => n.user_id === u.id && !n.read_at).length };
  if (u.role === "patient") o.has_profile = !!db.patients[u.id];
  if (u.role === "therapist") { o.therapist_status = db.therapists[u.id].status; o.chini_code = db.therapists[u.id].chini_code; }
  if (u.role === "admin") { o.admin_role = u.admin_role; o.name = u.name; }
  return o;
}
function application(tid) {
  const t = db.therapists[tid];
  const data = (t.draft || t.pending)?.data || clone(t.approved || empty());
  return { status: t.status, published: t.published, chini_code: t.chini_code, current_step: t.current_step, data,
    has_draft: !!t.draft, pending_change: t.pending && t.approved ? { version_id: t.pending.id, submitted_at: t.pending.submitted_at, changed_fields: diff(t.approved, t.pending.data).map(c => c.field) } : null,
    is_approved: !!t.approved, missing: missing(t, data), documents: t.documents, reviews: t.reviews.slice().reverse(),
    last_review_note: t.reviews.length ? t.reviews[t.reviews.length - 1].reason : null };
}
function review(t, decision, reason, admin) { t.reviews.push({ decision, reason: reason || null, created_at: now(), reviewer_name: admin?.name }); }
function apply(t, data) {
  if (t.approved_version_id) { const v = t.versions.find(x => x.id === t.approved_version_id); if (v) v.status = "superseded"; }
  const v = { id: nextId(), no: t.versions.length + 1, status: "approved", data: clone(data), at: now() };
  t.versions.push(v); t.approved = clone(data); t.approved_version_id = v.id; t.updated_at = now();
}

// ---------------------------------------------------------------- routes
export async function handle(method, path, q, body) {
  load();
  const r = route(method, path, q, body || {});
  save();
  return clone(r === undefined ? { ok: true } : r);
}

function route(M, P, q, b) {
  let m;
  const is = (method, re) => M === method && (m = P.match(re));

  // ---- config / auth
  if (is("GET", /^\/api\/config\/public$/)) return { appointments_enabled: db.settings.appointments_enabled, otp_dev_mode: true, environment: "demo", support_email: "support@example.com", support_phone: "", services: SERVICES };
  if (is("GET", /^\/api\/auth\/me$/)) { const u = need("any"); return { user: userOut(u), csrf_token: "demo" }; }
  if (is("POST", /^\/api\/auth\/otp\/request$/)) {
    const ph = normPhone(b.phone); if (!ph) err(422, "invalid_phone", "Enter a valid Bangladesh mobile number.");
    return { sent: true, phone_masked: `${ph.slice(0, 4)} ${ph.slice(4, 6)}•• •••${ph.slice(-3)}`, expires_in: 300, resend_in: 30, dev_mode: true };
  }
  if (is("POST", /^\/api\/auth\/otp\/verify$/)) {
    const ph = normPhone(b.phone); if (!ph) err(422, "invalid_phone", "Enter a valid Bangladesh mobile number.");
    const code = String(b.code || "").trim().replace(/[০-৯]/g, d => "০১২৩৪৫৬৭৮৯".indexOf(d));
    if (code !== OTP) err(400, "otp_invalid", "The code is incorrect. In the demo it is 123456.");
    let u = db.users.find(x => x.phone === ph), isNew = false;
    if (u && u.status === "suspended") err(403, "account_suspended", "This account is suspended.");
    if (!u) {
      isNew = true; u = { id: nextId(), phone: ph, role: b.role === "therapist" ? "therapist" : "patient", status: "active", language: b.language || "bn", created_at: now() };
      db.users.push(u);
      if (u.role === "therapist") db.therapists[u.id] = { status: "draft", published: false, chini_code: null, current_step: 1, draft: null, pending: null, approved: null, versions: [], approved_version_id: null, documents: [], reviews: [], updated_at: now() };
    }
    db.session = u.id;
    const out = userOut(u);
    let next = "dashboard";
    if (u.role === "patient" && !out.has_profile) next = "create_profile";
    if (u.role === "therapist" && ["draft", "changes_requested"].includes(db.therapists[u.id].status)) next = "application";
    return { user: out, csrf_token: "demo", is_new: isNew, next };
  }
  if (is("POST", /^\/api\/auth\/logout(-all)?$/)) { db.session = null; return; }
  if (is("PUT", /^\/api\/auth\/language$/)) { const u = need("any"); u.language = b.language; return { language: b.language }; }
  if (is("POST", /^\/api\/admin\/auth\/login$/)) {
    const u = admins().find(a => a.email === String(b.email || "").trim().toLowerCase());
    if (!u || b.password !== "dev-admin-password") err(401, "invalid_credentials", "Demo admin: admin@chini.local / dev-admin-password");
    db.session = u.id; return { user: userOut(u), csrf_token: "demo" };
  }

  // ---- geography
  if (is("GET", /^\/api\/geo\/divisions$/)) return GEO.divisions;
  if (is("GET", /^\/api\/geo\/districts$/)) return GEO.districts.filter(d => !q.division_id || d.division_id === +q.division_id);
  if (is("GET", /^\/api\/geo\/upazilas$/)) return GEO.upazilas.filter(u => u.district_id === +q.district_id);
  if (is("GET", /^\/api\/geo\/thanas$/)) return GEO.thanas.filter(t => t.district_id === +q.district_id && (!q.upazila_id || !t.upazila_id || t.upazila_id === +q.upazila_id));

  // ---- public directory
  if (is("GET", /^\/api\/public\/therapists$/)) {
    let ids = Object.keys(db.therapists).map(Number).filter(isPublic);
    const term = (q.q || "").trim().toLowerCase();
    let res = ids.map(id => ({ id, t: db.therapists[id], d: db.therapists[id].approved }));
    if (term) res = res.filter(x => /^\d{4}$/.test(term) ? x.t.chini_code === term
      : [x.d.personal.full_name, x.d.personal.full_name_bn, ...x.d.practice.locations.map(l => `${l.workplace} ${l.area || ""}`)].join(" ").toLowerCase().includes(term));
    if (q.profession) res = res.filter(x => x.d.practice.profession === q.profession);
    if (q.chini_code) res = res.filter(x => x.t.chini_code === q.chini_code);
    if (q.service) res = res.filter(x => x.d.practice.services.includes(q.service));
    if (q.min_experience) res = res.filter(x => x.d.practice.experience_years >= +q.min_experience);
    if (q.home_visit === "true") res = res.filter(x => x.d.practice.home_visit);
    for (const k of ["division_id", "district_id", "upazila_id", "thana_id"]) if (q[k]) res = res.filter(x => x.d.practice.locations.some(l => l[k] === +q[k]));
    if (q.area) res = res.filter(x => x.d.practice.locations.some(l => (l.area || "").toLowerCase().includes(q.area.toLowerCase())));
    const dist = (x) => {
      const lat = +q.lat, lng = +q.lng, k = Math.cos(lat * Math.PI / 180);
      const ds = x.d.practice.locations.filter(l => l.latitude != null).map(l => Math.hypot(l.latitude - lat, (l.longitude - lng) * k) * 111);
      return ds.length ? Math.min(...ds) : null;
    };
    const geo = q.lat && q.lng;
    if (geo) { res.forEach(x => { x.km = dist(x); }); res = res.filter(x => x.km !== null && x.km <= (+q.radius_km || 25)); }
    const sort = q.sort || "relevance";
    if (geo && (sort === "distance" || sort === "relevance")) res.sort((a, b2) => a.km - b2.km);
    else if (sort === "experience") res.sort((a, b2) => b2.d.practice.experience_years - a.d.practice.experience_years);
    else if (sort === "name") res.sort((a, b2) => a.d.personal.full_name.localeCompare(b2.d.personal.full_name));
    const out = page(res, q, 20);
    out.items = out.items.map(x => ({ ...shape(x.id, false), ...(x.km != null ? { distance_km: Math.round(x.km * 10) / 10 } : {}) }));
    out.page_size = Math.min(out.page_size, 50);
    out.sorted_by_distance = !!geo;
    return out;
  }
  if (is("GET", /^\/api\/public\/therapists\/(\d+)$/)) { if (!isPublic(+m[1])) err(404, "therapist_not_found", "This profile is not available."); return shape(+m[1], true); }

  // ---- notifications / account
  if (is("GET", /^\/api\/notifications$/)) {
    const u = need("any"); const list = db.notifs.filter(n => n.user_id === u.id).reverse();
    return { ...page(list, q), unread: list.filter(n => !n.read_at).length };
  }
  if (is("POST", /^\/api\/notifications\/read$/)) { const u = need("any"); db.notifs.filter(n => n.user_id === u.id).forEach(n => { n.read_at = n.read_at || now(); }); return; }
  if (is("POST", /^\/api\/account\/deletion-request$/)) { const u = need("any"); u.deletion_requested_at = now(); return { ok: true }; }

  if (P.startsWith("/api/patient/")) return patient(M, P, q, b, need("patient"));
  if (P.startsWith("/api/therapist/")) return therapist(M, P, q, b, need("therapist"));
  if (P.startsWith("/api/admin/")) return admin(M, P, q, b, need("admin"));
  err(404, "not_found", "Not found.");
}

function patient(M, P, q, b, u) {
  let m; const is = (method, re) => M === method && (m = P.match(re));
  if (is("GET", /profile$/)) { const p = db.patients[u.id]; if (!p) err(404, "profile_not_found", "Create your profile first."); return { ...p, phone_e164: u.phone, language: u.language }; }
  if (is("PUT", /profile$/)) {
    if (!b.full_name || b.full_name.trim().length < 2) err(422, "validation_error", "Please check the highlighted fields.", { fields: [{ loc: "full_name", msg: "Enter your full name" }] });
    if (b.district_id) { const d = geoName(GEO.districts, b.district_id); if (!d || (b.division_id && d.division_id !== b.division_id)) err(422, "invalid_location", "District does not belong to the selected division."); }
    const { language, ...rest } = b; db.patients[u.id] = { user_id: u.id, ...rest, updated_at: now() };
    if (language) u.language = language;
    return { ...db.patients[u.id], phone_e164: u.phone, language: u.language };
  }
  if (is("GET", /saved\/ids$/)) return db.saved.filter(s => s.pid === u.id).map(s => s.tid);
  if (is("GET", /saved$/)) {
    const list = db.saved.filter(s => s.pid === u.id).reverse().map(s => isPublic(s.tid)
      ? { ...shape(s.tid, false), available: true, saved_at: s.at }
      : { id: s.tid, name: tname(s.tid), profession: db.therapists[s.tid]?.approved?.practice.profession, chini_code: db.therapists[s.tid]?.chini_code, phone: null, photo_url: null, locations: [], services: [], verified: false, available: false, saved_at: s.at });
    return page(list, q);
  }
  if (is("POST", /saved\/(\d+)$/)) { const tid = +m[1]; if (!isPublic(tid)) err(404, "therapist_not_found"); if (!db.saved.some(s => s.pid === u.id && s.tid === tid)) db.saved.push({ pid: u.id, tid, at: now() }); return { saved: true }; }
  if (is("DELETE", /saved\/(\d+)$/)) { db.saved = db.saved.filter(s => !(s.pid === u.id && s.tid === +m[1])); return { saved: false }; }
  if (is("POST", /therapists\/(\d+)\/call$/)) {
    const tid = +m[1]; if (!isPublic(tid)) err(404, "therapist_not_found");
    const phone = shape(tid, false).phone; if (!phone) err(404, "no_public_phone", "This therapist has not published a phone number.");
    db.contacts.push({ id: nextId(), pid: u.id, tid, shared: !!b.share_details, created_at: now() });
    if (b.share_details) touchLink(u.id, tid, "call");
    return { tel: "tel:" + phone, phone };
  }
  if (is("GET", /contacts$/)) return page(db.contacts.filter(c => c.pid === u.id).reverse().map(c => ({ ...c, therapist_id: c.tid, event_type: "call_tap", display_name: tname(c.tid) })), q);
  if (is("GET", /sharing$/)) return db.links.filter(l => l.pid === u.id && !l.revoked).map(l => ({ therapist_id: l.tid, display_name: tname(l.tid), profession: db.therapists[l.tid].approved.practice.profession, chini_code: db.therapists[l.tid].chini_code }));
  if (is("DELETE", /sharing\/(\d+)$/)) { db.links.filter(l => l.pid === u.id && l.tid === +m[1]).forEach(l => { l.revoked = true; }); return; }
  if (is("POST", /therapists\/(\d+)\/report$/)) { db.reports.push({ id: nextId(), therapist_id: +m[1], reason: b.reason, details: b.details, status: "open", created_at: now() }); return; }
  if (is("GET", /appointments$/)) return page(db.appts.filter(a => a.patient_id === u.id).reverse().map(apptOut), q);
  if (is("POST", /appointments$/)) {
    if (!db.patients[u.id]) err(400, "profile_required", "Complete your profile before requesting an appointment.");
    if (!isPublic(b.therapist_id)) err(404, "therapist_not_found");
    const a = { id: nextId(), patient_id: u.id, therapist_id: b.therapist_id, service_code: b.service_code, preferred_date: b.preferred_date,
      preferred_time: b.preferred_time, patient_message: b.message, status: "requested", therapist_response: null, created_at: now() };
    db.appts.push(a); touchLink(u.id, b.therapist_id, "appointment"); notify(b.therapist_id, "appointment_requested", { appointment_id: a.id });
    return apptOut(a);
  }
  if (is("POST", /appointments\/(\d+)\/cancel$/)) return respond(+m[1], u, "patient", "cancel");
  err(404, "not_found");
}

function touchLink(pid, tid, source) {
  const l = db.links.find(x => x.pid === pid && x.tid === tid);
  if (l) { l.revoked = false; l.share = true; l.at = now(); } else db.links.push({ pid, tid, source, share: true, created: now(), at: now(), revoked: false });
}
const apptOut = a => ({ ...a, therapist_name: tname(a.therapist_id), chini_code: db.therapists[a.therapist_id]?.chini_code, patient_name: db.patients[a.patient_id]?.full_name });
const MOVES = { "requested|therapist|accept": "accepted", "requested|therapist|decline": "declined", "requested|patient|cancel": "cancelled",
  "accepted|patient|cancel": "cancelled", "accepted|therapist|cancel": "cancelled", "accepted|therapist|complete": "completed" };
function respond(id, u, role, action, message) {
  const a = db.appts.find(x => x.id === id && (role === "patient" ? x.patient_id : x.therapist_id) === u.id);
  if (!a) err(404, "appointment_not_found");
  const next = MOVES[`${a.status}|${role}|${action}`]; if (!next) err(409, "invalid_transition", `Cannot ${action} a request that is ${a.status}.`);
  a.status = next; if (role === "therapist" && message) a.therapist_response = message;
  notify(role === "therapist" ? a.patient_id : a.therapist_id, "appointment_" + next, { appointment_id: id });
  return apptOut(a);
}

function therapist(M, P, q, b, u) {
  let m; const is = (method, re) => M === method && (m = P.match(re));
  const t = db.therapists[u.id];
  const locked = () => ["submitted", "under_review", "resubmitted", "rejected", "suspended"].includes(t.status);
  if (is("GET", /dashboard$/)) return { status: t.status, published: t.published, chini_code: t.chini_code, display_name: tname(u.id),
    patients: db.links.filter(l => l.tid === u.id && !l.revoked).length, open_requests: db.appts.filter(a => a.therapist_id === u.id && a.status === "requested").length,
    saved_by: db.saved.filter(s => s.tid === u.id).length, pending_change: !!(t.pending && t.approved) };
  if (is("GET", /application$/)) return application(u.id);
  if (is("PUT", /application\/sections\/(\w+)$/)) {
    if (locked()) err(409, "application_locked", "Your application is with a reviewer and cannot be edited now.");
    if (t.pending) err(409, "change_pending", "A profile change is awaiting review. Withdraw it to edit again.");
    if (m[1] === "personal" && b.data.nid_number && !/^(\d{10}|\d{13}|\d{17})$/.test(b.data.nid_number))
      err(422, "validation_error", "Please check the highlighted fields.", { fields: [{ loc: "nid_number", msg: "NID must have 10, 13 or 17 digits" }] });
    if (!t.draft) t.draft = { data: clone(t.approved || empty()) };
    t.draft.data[m[1]] = b.data;
    if (b.step) t.current_step = b.step;
    return { saved: true };
  }
  if (is("POST", /application\/submit$/)) {
    if (!t.draft) err(400, "nothing_to_submit", "There are no unsaved changes to submit.");
    const miss = missing(t, t.draft.data); if (miss.length) err(422, "application_incomplete", "Some required information is missing.", { missing: miss });
    if (!t.approved) {
      t.status = t.status === "changes_requested" ? "resubmitted" : "submitted";
      t.pending = { id: nextId(), data: t.draft.data, submitted_at: now() }; t.versions.push({ id: t.pending.id, no: t.versions.length + 1, status: "pending", data: t.draft.data, at: now() });
      t.draft = null; t.submitted_at = now();
      notify(u.id, "application_submitted"); admins().forEach(a => notify(a.id, "admin_new_application"));
      return { status: t.status, review_required: true };
    }
    const changes = diff(t.approved, t.draft.data);
    if (!changes.length) { t.draft = null; err(400, "no_changes", "Nothing has changed compared with your approved profile."); }
    if (changes.some(c => c.critical) || db.settings.minor_changes_require_review) {
      t.pending = { id: nextId(), data: t.draft.data, submitted_at: now() }; t.versions.push({ id: t.pending.id, no: t.versions.length + 1, status: "pending", data: t.draft.data, at: now() });
      t.draft = null; notify(u.id, "profile_update_pending"); admins().forEach(a => notify(a.id, "admin_new_application"));
      return { status: t.status, review_required: true, changed_fields: changes.map(c => c.field) };
    }
    apply(t, t.draft.data); t.draft = null;
    return { status: t.status, review_required: false, changed_fields: changes.map(c => c.field) };
  }
  if (is("POST", /application\/withdraw$/)) {
    if (!t.pending) err(404, "no_pending_change");
    t.draft = { data: t.pending.data }; t.versions = t.versions.filter(v => v.id !== t.pending.id); t.pending = null;
    if (!t.approved) t.status = t.status === "resubmitted" ? "changes_requested" : "draft";
    return;
  }
  if (is("DELETE", /application\/draft$/)) { t.draft = null; return; }
  if (is("POST", /photo$/)) return { photo_key: `photos/${u.id}/demo-${Date.now()}.jpg` };
  if (is("GET", /documents$/)) return t.documents;
  if (is("POST", /documents$/)) {
    if (locked()) err(409, "application_locked", "Documents cannot be changed while the application is in review.");
    const f = b.get ? b.get("file") : null, type = b.get ? b.get("doc_type") : "other";
    if (!f) err(422, "empty_file", "Choose a file.");
    if (!/^(application\/pdf|image\/(jpeg|png))$/.test(f.type)) err(415, "file_type_not_allowed", "Upload a PDF, JPG or PNG file.");
    if (f.size > 10 * 1024 * 1024) err(413, "file_too_large", "Files must be under 10 MB.");
    const d = { id: nextId(), doc_type: type, original_name: f.name, mime_type: f.type, size_bytes: f.size, uploaded_at: now() };
    t.documents.push(d); return d;
  }
  if (is("DELETE", /documents\/(\d+)$/)) { t.documents = t.documents.filter(d => d.id !== +m[1]); return; }
  if (is("GET", /public-preview$/)) { if (!t.approved) err(404, "not_approved_yet", "Your public profile appears after approval."); return { ...shape(u.id, true), published: t.published && t.status === "approved" }; }
  if (is("GET", /patients$/)) return page(db.links.filter(l => l.tid === u.id && !l.revoked).reverse().map(l => {
    const pp = db.patients[l.pid] || {}, pu = byId(db.users, l.pid), last = db.appts.filter(a => a.patient_id === l.pid && a.therapist_id === u.id).pop();
    const d = geoName(GEO.districts, pp.district_id);
    return { patient_id: l.pid, source: l.source, share_phone: l.share, last_interaction_at: l.at, full_name: pp.full_name, phone_e164: l.share ? pu?.phone : null,
      district_en: d?.name_en, district_bn: d?.name_bn, latest_appointment_status: last?.status, latest_message: last?.patient_message };
  }), q);
  if (is("GET", /appointments$/)) return page(db.appts.filter(a => a.therapist_id === u.id).reverse().map(apptOut), q);
  if (is("POST", /appointments\/(\d+)\/respond$/)) return respond(+m[1], u, "therapist", b.action, b.message);
  err(404, "not_found");
}

function admin(M, P, q, b, u) {
  let m; const is = (method, re) => M === method && (m = P.match(re));
  const T = id => { const t = db.therapists[id]; if (!t) err(404, "therapist_not_found"); return t; };
  const needReason = () => { if (!b.reason || b.reason.length < 5) err(422, "validation_error", "Please give a reason (at least 5 characters)."); };
  const superOnly = () => { if (u.admin_role !== "super_admin") err(403, "super_admin_only"); };
  const therapistUsers = db.users.filter(x => x.role === "therapist");
  if (is("GET", /dashboard$/)) {
    const ts = Object.values(db.therapists), c = s => ts.filter(t => t.status === s).length;
    const approved = Object.entries(db.therapists).filter(([, t]) => t.status === "approved" && t.approved);
    const byDist = {};
    approved.forEach(([, t]) => t.approved.practice.locations.forEach(l => { byDist[l.district_id] = (byDist[l.district_id] || 0) + 1; }));
    return { patients: db.users.filter(x => x.role === "patient").length, therapists: therapistUsers.length, approved: c("approved"),
      pending: c("submitted") + c("under_review") + c("resubmitted"), changes_requested: c("changes_requested"),
      pending_profile_changes: ts.filter(t => t.pending && t.approved).length, suspended: db.users.filter(x => x.status === "suspended").length,
      open_reports: db.reports.filter(r => r.status === "open").length, deletion_requests: db.users.filter(x => x.deletion_requested_at).length,
      by_profession: Object.fromEntries(["PT", "OT", "SLT"].map(p => [p, approved.filter(([, t]) => t.approved.practice.profession === p).length])),
      by_division: GEO.divisions.map(dv => ({ ...dv, n: approved.filter(([, t]) => t.approved.practice.locations.some(l => l.division_id === dv.id)).length })),
      top_districts: Object.entries(byDist).sort((a, b2) => b2[1] - a[1]).slice(0, 10).map(([id, n]) => ({ ...geoName(GEO.districts, +id), n })),
      recent_activity: Object.entries(db.therapists).flatMap(([id, t]) => t.reviews.map(r => ({ ...r, therapist_id: +id, display_name: tname(+id) })))
        .sort((a, b2) => b2.created_at.localeCompare(a.created_at)).slice(0, 10),
      codes: codeUsage() };
  }
  if (is("GET", /applications$/)) {
    let list = Object.entries(db.therapists).map(([id, t]) => ({ id: +id, t }));
    if (q.kind === "changes") list = list.filter(x => x.t.approved && x.t.pending);
    else if (q.status) list = list.filter(x => x.t.status === q.status);
    else list = list.filter(x => ["submitted", "under_review", "resubmitted"].includes(x.t.status));
    const term = (q.q || "").toLowerCase();
    const rows = list.map(({ id, t }) => {
      const d = t.approved || t.pending?.data || t.draft?.data || {};
      return { therapist_id: id, status: t.status, published: t.published, profession: d.practice?.profession, name: tname(id), chini_code: t.chini_code,
        phone_e164: byId(db.users, id)?.phone, submitted_at: t.submitted_at, updated_at: t.updated_at };
    }).filter(r => (!q.profession || r.profession === q.profession) && (!term || `${r.name} ${r.phone_e164} ${r.chini_code}`.toLowerCase().includes(term)));
    return page(rows, q, 25);
  }
  if (is("GET", /therapists\/(\d+)$/)) {
    const id = +m[1], t = T(id), us = byId(db.users, id);
    return { therapist_id: id, user: { phone_e164: us.phone, status: us.status, created_at: us.created_at },
      profile: { status: t.status, published: t.published, chini_code: t.chini_code, approved_version_id: t.approved_version_id },
      pending: t.pending && { version_id: t.pending.id, data: t.pending.data, submitted_at: t.pending.submitted_at, changes: diff(t.approved, t.pending.data) },
      approved: t.approved, documents: t.documents, reviews: t.reviews.slice().reverse(),
      versions: t.versions.slice().reverse().map(v => ({ id: v.id, version_no: v.no, status: v.status, created_at: v.at, reviewed_at: v.status === "approved" ? v.at : null })),
      missing: t.pending ? missing(t, t.pending.data) : [] };
  }
  if (is("POST", /therapists\/(\d+)\/([a-z-]+)$/)) {
    const id = +m[1], t = T(id), act = m[2], usr = byId(db.users, id);
    if (act === "start-review") { if (!["submitted", "resubmitted"].includes(t.status)) err(409, "invalid_status"); t.status = "under_review"; review(t, "under_review", null, u); notify(id, "application_under_review"); }
    else if (act === "approve") {
      if (!t.pending) err(409, "nothing_pending", "There is nothing waiting for approval.");
      const initial = !t.approved; t.versions = t.versions.filter(v => v.id !== t.pending.id); apply(t, t.pending.data); t.pending = null;
      let code = t.chini_code;
      if (initial) { code = assignCode(t, id); t.status = "approved"; t.published = true; t.approved_at = now(); }
      review(t, "approved", b.reason, u); notify(id, initial ? "application_approved" : "profile_update_approved", { chini_code: code });
      audit(u, initial ? "application.approved" : "profile_change.approved", id, { new_value: { chini_code: code }, reason: b.reason });
      return { status: "approved", chini_code: code };
    } else if (act === "reject") {
      needReason(); if (!t.pending) err(409, "nothing_pending");
      t.versions.forEach(v => { if (v.id === t.pending.id) v.status = "rejected"; }); t.pending = null;
      if (!t.approved) { t.status = "rejected"; t.published = false; notify(id, "application_rejected", { reason: b.reason }); } else notify(id, "profile_update_rejected", { reason: b.reason });
      review(t, "rejected", b.reason, u);
    } else if (act === "request-changes") {
      needReason(); if (!t.pending) err(409, "nothing_pending");
      t.draft = { data: t.pending.data }; t.versions = t.versions.filter(v => v.id !== t.pending.id); t.pending = null;
      if (!t.approved) t.status = "changes_requested";
      review(t, "changes_requested", b.reason, u); notify(id, "corrections_requested", { reason: b.reason });
    } else if (act === "suspend") { needReason(); t.status = "suspended"; t.published = false; usr.status = "suspended"; if (db.session === id) db.session = null; review(t, "suspended", b.reason, u); notify(id, "account_suspended", { reason: b.reason }); }
    else if (act === "reactivate") { needReason(); t.status = t.approved ? "approved" : "draft"; t.published = !!t.approved; usr.status = "active"; review(t, "reactivated", b.reason, u); notify(id, "account_reactivated"); }
    else if (act === "unpublish") { needReason(); t.published = false; review(t, "unpublished", b.reason, u); notify(id, "profile_unpublished", { reason: b.reason }); }
    else if (act === "publish") { needReason(); if (t.status !== "approved") err(409, "not_approved", "Only approved profiles can be published."); t.published = true; review(t, "republished", b.reason, u); }
    else err(404, "not_found");
    audit(u, `therapist.${act}`, id, { reason: b.reason || null });
    return;
  }
  if (is("GET", /therapists\/(\d+)\/versions\/(\d+)\/compare$/)) {
    const t = T(+m[1]), v = t.versions.find(x => x.id === +m[2]) || (t.pending?.id === +m[2] ? { data: t.pending.data } : null);
    if (!v) err(404, "version_not_found");
    const base = t.approved_version_id !== +m[2] ? t.approved : null;
    return { version_id: +m[2], against_id: base ? t.approved_version_id : null, changes: diff(base, v.data) };
  }
  if (is("POST", /therapists\/(\d+)\/versions\/(\d+)\/rollback$/)) {
    superOnly(); needReason(); const t = T(+m[1]), v = t.versions.find(x => x.id === +m[2]);
    if (!v || !["approved", "superseded"].includes(v.status)) err(409, "not_an_approved_version");
    apply(t, v.data); review(t, "rolled_back", b.reason, u); audit(u, "profile.rolled_back", +m[1], { reason: b.reason }); return;
  }
  if (is("GET", /codes$/)) {
    const rows = Object.entries(db.codes).map(([code, c]) => ({ code, status: c.status, therapist_id: c.therapist_id, display_name: c.therapist_id ? tname(c.therapist_id) : null, assigned_at: c.at, note: c.note }))
      .filter(r => !q.status || r.status === q.status).sort((a, b2) => b2.assigned_at.localeCompare(a.assigned_at));
    return { ...page(rows, q, 50), usage: codeUsage() };
  }
  if (is("GET", /codes\/([^/]+)$/)) {
    const code = decodeURIComponent(m[1]); if (!/^\d{4}$/.test(code)) err(422, "invalid_chini_code", "A CHINI code has exactly four digits.");
    const c = db.codes[code]; if (!c) err(404, "chini_code_not_found", "No therapist has this code.");
    return { code, status: c.status, therapist_id: c.therapist_id, note: c.note, display_name: c.therapist_id ? tname(c.therapist_id) : null, profile_status: c.therapist_id ? db.therapists[c.therapist_id].status : null };
  }
  if (is("POST", /codes\/reserve$/)) {
    superOnly(); if (!/^\d{4}$/.test(b.code || "")) err(422, "invalid_chini_code", "A CHINI code has exactly four digits.");
    if (db.codes[b.code]) err(409, "chini_code_taken", "That code is already registered.");
    db.codes[b.code] = { status: "reserved", therapist_id: null, at: now(), note: b.note }; return;
  }
  if (is("DELETE", /codes\/(\d{4})\/reservation$/)) { superOnly(); if (db.codes[m[1]]?.status === "reserved") delete db.codes[m[1]]; return; }
  if (is("GET", /users$/)) {
    const term = (q.q || "").toLowerCase();
    const rows = db.users.filter(x => x.role !== "admin").map(x => ({ id: x.id, role: x.role, status: x.status, phone_e164: x.phone, created_at: x.created_at,
      deletion_requested_at: x.deletion_requested_at, name: x.role === "patient" ? db.patients[x.id]?.full_name : tname(x.id) }))
      .filter(r => (!q.role || r.role === q.role) && (!q.status || r.status === q.status) && (!term || `${r.name} ${r.phone_e164}`.toLowerCase().includes(term))).reverse();
    return page(rows, q, 25);
  }
  if (is("POST", /users\/(\d+)\/(suspend|reactivate|erase)$/)) {
    const x = byId(db.users, m[1]); if (!x) err(404, "user_not_found");
    if (m[2] === "erase") { superOnly(); delete db.patients[x.id]; db.saved = db.saved.filter(s => s.pid !== x.id); x.phone = null; x.status = "deleted"; return; }
    needReason();
    if (x.role === "therapist") return admin("POST", `/api/admin/therapists/${x.id}/${m[2]}`, q, b, u);
    x.status = m[2] === "suspend" ? "suspended" : "active"; if (db.session === x.id) db.session = null; return;
  }
  if (is("GET", /reports$/)) return page(db.reports.filter(r => r.status === (q.status || "open")).map(r => ({ ...r, display_name: tname(r.therapist_id), chini_code: db.therapists[r.therapist_id]?.chini_code })), q);
  if (is("POST", /reports\/(\d+)\/close$/)) { const r = byId(db.reports, m[1]); if (r) r.status = q.status || "reviewed"; return; }
  if (is("GET", /audit-logs$/)) return page(db.audit.filter(a => (!q.action || a.action === q.action) && (!q.target_id || a.target_id === q.target_id)), q, 50);
  if (is("GET", /settings$/)) return db.settings;
  if (is("PUT", /settings$/)) { superOnly(); db.settings[b.key] = b.value; return db.settings; }
  if (is("GET", /admins$/)) return admins().map(a => ({ user_id: a.id, email: a.email, full_name: a.name, admin_role: a.admin_role, status: a.status, has_2fa: false }));
  if (is("POST", /admins$/)) err(400, "demo_only", "Creating administrators is disabled in the demo.");
  err(404, "not_found");
}
