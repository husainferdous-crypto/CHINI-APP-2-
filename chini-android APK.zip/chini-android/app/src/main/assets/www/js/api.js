// DEMO BUILD: requests are answered by an in-browser demo backend (js/mock.js) instead of a server.
import { state } from "./state.js";

export class ApiError extends Error {
  constructor(status, code, message, details) {
    super(message || code);
    this.status = status; this.code = code; this.details = details || {};
  }
}

async function request(method, path, { body, query, form } = {}) {
  const { handle } = await import("./mock.js");
  const q = {};
  for (const [k, v] of Object.entries(query || {})) if (v !== undefined && v !== null && v !== "") q[k] = String(v);
  const [p, qs] = path.split("?");
  if (qs) for (const [k, v] of new URLSearchParams(qs)) q[k] = v;
  await new Promise(r => setTimeout(r, 120));
  try {
    return await handle(method, p, q, form || body);
  } catch (e) {
    if (e instanceof ApiError) {
      if (e.status === 401 && state.user) { state.user = null; state.csrf = null; }
      throw e;
    }
    console.error(e);
    throw new ApiError(500, "server_error", "Something went wrong.");
  }
}

export const api = {
  get: (p, query) => request("GET", p, { query }),
  post: (p, body, query) => request("POST", p, { body: body ?? {}, query }),
  put: (p, body) => request("PUT", p, { body }),
  del: (p) => request("DELETE", p, {}),
  upload: (p, form) => request("POST", p, { form }),
  blob: async () => new Blob(["CHINI demo: uploaded files are not stored in the demo version."], { type: "text/plain" }),
};
