// Minimal hash router: "#/t/12?x=1" -> handler({ params: {id: "12"}, query: URLSearchParams })
const routes = [];
let notFound = null;
let before = null;

export function route(pattern, handler, opts = {}) {
  const keys = [];
  const re = new RegExp("^" + pattern.replace(/:([a-z_]+)/gi, (_, k) => { keys.push(k); return "([^/]+)"; }) + "$");
  routes.push({ re, keys, handler, opts });
}
export function fallback(handler) { notFound = handler; }
export function guard(fn) { before = fn; }

export function go(path, replace = false) {
  const target = "#" + path;
  if (replace) { history.replaceState(null, "", target); resolve(); }
  else if (location.hash === target) resolve();
  else location.hash = target;
}

export function currentPath() { return (location.hash.slice(1) || "/").split("?")[0]; }

export async function resolve() {
  const raw = location.hash.slice(1) || "/";
  const [path, qs = ""] = raw.split("?");
  const query = new URLSearchParams(qs);
  for (const r of routes) {
    const m = path.match(r.re);
    if (!m) continue;
    const params = Object.fromEntries(r.keys.map((k, i) => [k, decodeURIComponent(m[i + 1])]));
    if (before) {
      const redirect = await before(r.opts, path);
      if (redirect) { go(redirect, true); return; }
    }
    window.scrollTo(0, 0);
    return r.handler({ params, query, path });
  }
  notFound && notFound({ path });
}

export function start() {
  window.addEventListener("hashchange", resolve);
  return resolve();
}
