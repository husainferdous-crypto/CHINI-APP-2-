// Therapist screens: dashboard, 5-step application wizard with autosave, status, preview, patients, appointments.
import { api } from "../api.js";
import { fmtDate, getLang, nm, num, t } from "../i18n.js";
import { go } from "../router.js";
import { state } from "../state.js";
import {
  avatar, checkbox, clear, codeChip, confirmDialog, empty, field, geoPicker, h, icon, input, load, modal, pager, select,
  setFieldErrors, showError, statusPill, toast, verifiedBadge,
} from "../ui.js";
import { refreshMe, view } from "../app.js";
import { logout } from "./patient.js";

const page = (...c) => clear(view()).append(h("div.page", ...c));
const LOCKED = new Set(["submitted", "under_review", "resubmitted", "rejected", "suspended"]);
const STEPS = ["wiz.step1", "wiz.step2", "wiz.step3", "wiz.step4", "wiz.step5"];
const DOC_TYPES = ["national_id", "degree_certificate", "mark_sheet", "internship_certificate",
  "registration_certificate", "experience_letter", "other"];

// ---------------------------------------------------------------------------------
// Dashboard
// ---------------------------------------------------------------------------------
export function dashboard() {
  const box = h("div");
  page(box);
  load(box, async () => {
    const d = await api.get("/api/therapist/dashboard");
    const approved = d.status === "approved";
    const app = approved ? null : await api.get("/api/therapist/application");
    return [
      h("h1.h2", t("th.dashboard")),
      h("section.card.status-card",
        h("div.row-between", h("span.muted", t("th.status")), statusPill(d.status)),
        h("p", t("status.desc." + d.status)),
        approved ? h("div.code-big", h("span", t("th.code_label") + ":"), h("strong", num(d.chini_code)), codeChip(d.chini_code)) : null,
        approved ? verifiedBadge() : null,
        approved && !d.published ? h("p.alert.alert-warn", t("th.unpublished")) : null,
        d.pending_change ? h("p.alert.alert-info", t("th.pending_change")) : null,
        app && app.last_review_note && d.status !== "submitted" ? h("div.alert.alert-warn", h("strong", t("status.reviewer_note") + ": "), app.last_review_note) : null,
        !approved && !LOCKED.has(d.status)
          ? h("a.btn.btn-primary.btn-block", { href: `#/therapist/apply/${app?.current_step || 1}` },
              app?.has_draft ? t("th.apply_continue") : t("th.apply_start"))
          : null,
        h("a.btn.btn-ghost.btn-block", { href: "#/therapist/status" }, t("th.status"))),
      approved ? h("div.stats",
        stat(t("th.patients"), d.patients, "#/therapist/patients"),
        state.config?.appointments_enabled ? stat(t("th.open_requests"), d.open_requests, "#/therapist/appointments") : null,
        stat(t("th.saved_by"), d.saved_by)) : null,
      approved ? h("div.stack",
        h("a.btn.btn-secondary.btn-block", { href: "#/therapist/apply/1" }, t("th.edit_profile")),
        h("a.btn.btn-ghost.btn-block", { href: "#/therapist/preview" }, t("th.preview"))) : null,
      h("button.btn.btn-ghost.btn-block", { type: "button", on: { click: logout } }, t("common.logout")),
    ];
  });
}

function stat(label, value, href) {
  const inner = [h("strong.stat-value", num(value ?? 0)), h("span.stat-label", label)];
  return href ? h("a.stat", { href }, inner) : h("div.stat", inner);
}

export function myProfile() {
  api.get("/api/therapist/dashboard").then(d => go(d.status === "approved" ? "/therapist/preview" : "/therapist/apply/1", true))
    .catch(showError);
}

// ---------------------------------------------------------------------------------
// Status
// ---------------------------------------------------------------------------------
export function status() {
  const box = h("div");
  page(box);
  load(box, async () => {
    const app = await api.get("/api/therapist/application");
    return [
      h("h1.h2", t("th.status")),
      h("section.card", h("div.row-between", h("strong", t("common.status")), statusPill(app.status)),
        h("p", t("status.desc." + app.status)),
        app.chini_code ? h("div.code-big", h("span", t("profile.code") + ":"), h("strong", num(app.chini_code)), codeChip(app.chini_code)) : null,
        app.pending_change ? h("div.alert.alert-info", t("th.pending_change"),
          h("button.btn.btn-ghost.btn-sm", { type: "button", on: { click: withdraw } }, t("wiz.withdraw"))) : null),
      app.reviews.length ? h("section.card", h("h2.h3", t("status.reviewer_note")),
        h("ul.timeline", app.reviews.map(r => h("li", h("div.row-between", statusPill(r.decision),
          h("small.muted", fmtDate(r.created_at, true))), r.reason ? h("p", r.reason) : null)))) : null,
    ];
  });
}

async function withdraw() {
  if (!(await confirmDialog(t("wiz.withdraw"), t("admin.confirm_action")))) return;
  try { await api.post("/api/therapist/application/withdraw"); toast(t("common.saved")); go("/therapist/apply/1"); }
  catch (err) { showError(err); }
}

// ---------------------------------------------------------------------------------
// Application wizard
// ---------------------------------------------------------------------------------
export function wizard({ params }) {
  const step = Math.min(5, Math.max(1, +params.step || 1));
  const box = h("div");
  page(box);
  load(box, async () => {
    const app = await api.get("/api/therapist/application");
    if (LOCKED.has(app.status) || app.pending_change) {
      return [h("h1.h2", t("th.status")), h("div.card", statusPill(app.status), h("p", t("wiz.locked")),
        app.pending_change ? h("button.btn.btn-secondary", { type: "button", on: { click: withdraw } }, t("wiz.withdraw")) : null,
        h("a.btn.btn-primary", { href: "#/therapist" }, t("th.dashboard")))];
    }
    const saved = h("span.autosave", { "aria-live": "polite" });
    const progress = h("ol.steps", STEPS.map((k, i) => h("li" + (i + 1 === step ? ".current" : i + 1 < step ? ".done" : ""),
      h("a", { href: `#/therapist/apply/${i + 1}`, "aria-current": i + 1 === step ? "step" : null },
        h("span.step-n", num(i + 1)), h("span.step-label", t(k))))));
    const builders = { 1: stepPersonal, 2: stepEducation, 3: stepPractice, 4: stepDocuments, 5: stepReview };
    const content = await builders[step](app, saved);
    return [
      h("div.row-between", h("h1.h2", app.is_approved ? t("th.edit_profile") : t("th.apply_start")), saved),
      progress, h("p.small.muted", `${num(step)}/${num(5)} · ${t(STEPS[step - 1])}`),
      content,
    ];
  });
}

/** Debounced autosave for one section. */
function autosaver(section, collect, saved, form, stepNo) {
  let timer = null;
  let inflight = Promise.resolve();
  async function save(explicit = false) {
    clearTimeout(timer);
    const data = collect();
    saved.textContent = t("common.saving");
    inflight = inflight.then(async () => {
      try {
        await api.put(`/api/therapist/application/sections/${section}`, { data, step: stepNo });
        saved.textContent = "✓ " + t("wiz.autosaved");
        setFieldErrors(form, []);
        return true;
      } catch (err) {
        saved.textContent = "";
        setFieldErrors(form, err.details?.fields);
        if (explicit) showError(err);
        return false;
      }
    });
    return inflight;
  }
  form.addEventListener("input", () => { clearTimeout(timer); timer = setTimeout(save, 1200); });
  form.addEventListener("change", () => { clearTimeout(timer); timer = setTimeout(save, 400); });
  return save;
}

function navButtons(stepNo, save) {
  return h("div.wizard-nav",
    stepNo > 1 ? h("a.btn.btn-ghost", { href: `#/therapist/apply/${stepNo - 1}` }, t("common.back")) : h("span"),
    h("button.btn.btn-primary", { type: "button", on: { click: async () => {
      const ok = save ? await save(true) : true;
      if (ok) go(`/therapist/apply/${stepNo + 1}`);
    } } }, t("wiz.save_continue")));
}

const val = el => (el.value || "").trim() || null;
const intOrNull = el => (el.value === "" ? null : parseInt(el.value, 10));

async function stepPersonal(app, saved) {
  const p = app.data.personal || {};
  const fullName = input({ name: "full_name", value: p.full_name || "", maxlength: 120, autocomplete: "name" });
  const fullNameBn = input({ name: "full_name_bn", value: p.full_name_bn || "", maxlength: 120, lang: "bn" });
  const dob = input({ name: "date_of_birth", type: "date", value: p.date_of_birth || "" });
  const gender = select([["", t("common.select")], ...["female", "male", "other", "prefer_not"].map(g => [g, t("wiz.gender." + g)])], p.gender || "", { name: "gender" });
  const nid = input({ name: "nid_number", value: p.nid_number || "", inputmode: "numeric", maxlength: 20, autocomplete: "off" });
  const email = input({ name: "email", type: "email", value: p.email || "", maxlength: 200 });
  const phone = input({ name: "public_phone", type: "tel", value: p.public_phone || state.user?.phone || "", maxlength: 20 });
  const show = checkbox(t("wiz.show_phone"), p.show_phone_public ?? true, { name: "show_phone_public" });
  let photoKey = p.photo_key || null;
  const photoBox = h("div.photo-box");
  const paintPhoto = () => clear(photoBox).append(
    avatar(photoKey ? `/api/therapist/photo?key=${encodeURIComponent(photoKey)}` : null, fullName.value || "?", "lg"));
  paintPhoto();
  const file = h("input", { type: "file", accept: "image/jpeg,image/png,image/webp", hidden: true });
  const form = h("form.card.form", { novalidate: true, on: { submit: e => e.preventDefault() } });
  const collect = () => ({
    full_name: val(fullName), full_name_bn: val(fullNameBn), date_of_birth: dob.value || null, gender: gender.value || null,
    nid_number: val(nid), email: val(email), public_phone: val(phone), show_phone_public: show.cb.checked, photo_key: photoKey,
  });
  const save = autosaver("personal", collect, saved, form, 1);
  file.addEventListener("change", async () => {
    if (!file.files[0]) return;
    const fd = new FormData(); fd.append("file", file.files[0]);
    saved.textContent = t("wiz.uploading");
    try { photoKey = (await api.upload("/api/therapist/photo", fd)).photo_key; paintPhoto(); await save(true); }
    catch (err) { showError(err); saved.textContent = ""; }
    file.value = "";
  });
  form.append(
    h("div.photo-row", photoBox, h("div",
      h("strong", t("wiz.photo")), h("p.small.muted", t("wiz.photo_hint")), file,
      h("button.btn.btn-secondary.btn-sm", { type: "button", on: { click: () => file.click() } }, photoKey ? t("wiz.change_photo") : t("wiz.upload_photo")))),
    field(t("wiz.full_name"), fullName), field(t("wiz.full_name_bn"), fullNameBn, null, { optional: true }),
    h("div.grid-2", field(t("wiz.dob"), dob), field(t("wiz.gender"), gender, null, { optional: true })),
    field(t("wiz.nid"), nid, t("wiz.nid_note")),
    field(t("wiz.email"), email, null, { optional: true }),
    field(t("wiz.public_phone"), phone), show.el,
    navButtons(1, save));
  return form;
}

async function stepEducation(app, saved) {
  const e = app.data.education || {};
  const rows = h("div.repeat");
  const addRow = (q = {}) => {
    const degree = input({ name: "degree", value: q.degree || "", maxlength: 150 });
    const inst = input({ name: "institution", value: q.institution || "", maxlength: 200 });
    const year = input({ name: "passing_year", type: "number", min: 1960, max: new Date().getFullYear() + 1, value: q.passing_year ?? "" });
    const result = input({ name: "result", value: q.result || "", maxlength: 40 });
    const pub = checkbox(t("wiz.show_public"), q.show_public ?? true);
    const row = h("div.repeat-row",
      field(t("wiz.degree"), degree), field(t("wiz.institution"), inst),
      h("div.grid-2", field(t("wiz.passing_year"), year), field(t("wiz.result"), result, t("wiz.result_note"), { optional: true })),
      pub.el,
      h("button.btn.btn-ghost.btn-sm", { type: "button", on: { click: () => { row.remove(); save(); } } }, t("common.remove")));
    row._get = () => ({ degree: val(degree), institution: val(inst), passing_year: intOrNull(year), result: val(result), show_public: pub.cb.checked });
    rows.append(row);
  };
  (e.qualifications?.length ? e.qualifications : [{}]).forEach(addRow);
  const body = input({ name: "registration_body", value: e.registration_body || "", maxlength: 150 });
  const regNo = input({ name: "registration_number", value: e.registration_number || "", maxlength: 60 });
  const intern = checkbox(t("wiz.internship"), !!e.internship_completed);
  const form = h("form.card.form", { novalidate: true, on: { submit: ev => ev.preventDefault() } });
  const collect = () => ({
    qualifications: [...rows.children].map(r => r._get()).filter(q => q.degree || q.institution),
    registration_body: val(body), registration_number: val(regNo), internship_completed: intern.cb.checked,
  });
  const save = autosaver("education", collect, saved, form, 2);
  form.append(h("h2.h3", t("wiz.qualifications")), rows,
    h("button.btn.btn-secondary.btn-sm", { type: "button", on: { click: () => addRow() } }, "+ " + t("wiz.add_qual")),
    h("hr"), field(t("wiz.reg_body"), body, null, { optional: true }), field(t("wiz.reg_no"), regNo, null, { optional: true }),
    intern.el, navButtons(2, save));
  return form;
}

async function stepPractice(app, saved) {
  const p = app.data.practice || {};
  const prof = select([["", t("common.select")], ...["PT", "OT", "SLT"].map(x => [x, t("prof." + x)])], p.profession || "", { name: "profession" });
  const desig = input({ name: "designation", value: p.designation || "", maxlength: 120 });
  const exp = input({ name: "experience_years", type: "number", min: 0, max: 60, value: p.experience_years ?? "" });
  const bio = h("textarea.input", { name: "bio", rows: 4, maxlength: 1500 }); bio.value = p.bio || "";
  const bioBn = h("textarea.input", { name: "bio_bn", rows: 4, maxlength: 1500, lang: "bn" }); bioBn.value = p.bio_bn || "";
  const hv = checkbox(t("wiz.home_visit"), !!p.home_visit);
  const servicesBox = h("div.check-grid");
  let chosen = new Set(p.services || []);
  const paintServices = () => {
    clear(servicesBox);
    for (const s of state.config?.services?.[prof.value] || []) {
      const c = checkbox(t("service." + s), chosen.has(s));
      c.cb.addEventListener("change", () => { c.cb.checked ? chosen.add(s) : chosen.delete(s); });
      servicesBox.append(c.el);
    }
    if (!prof.value) servicesBox.append(h("p.muted.small", t("wiz.profession")));
  };
  prof.addEventListener("change", () => { const allowed = new Set(state.config?.services?.[prof.value] || []); chosen = new Set([...chosen].filter(s => allowed.has(s))); paintServices(); });
  paintServices();

  const locs = h("div.repeat");
  const addLoc = (l = {}) => {
    const wp = input({ name: "workplace", value: l.workplace || "", maxlength: 200 });
    const addr = input({ name: "address_line", value: l.address_line || "", maxlength: 250 });
    const area = input({ name: "area", value: l.area || "", maxlength: 100 });
    const hours = input({ name: "working_hours", value: l.working_hours || "", maxlength: 200 });
    const lat = input({ name: "latitude", type: "number", step: "0.00001", value: l.latitude ?? "" });
    const lng = input({ name: "longitude", type: "number", step: "0.00001", value: l.longitude ?? "" });
    const geo = geoPicker(l, { required: true });
    const row = h("div.repeat-row",
      field(t("wiz.workplace"), wp), field(t("wiz.address_line"), addr, null, { optional: true }),
      field(t("geo.area"), area, null, { optional: true }), geo.el,
      field(t("wiz.working_hours"), hours, null, { optional: true }),
      h("details", h("summary.small", t("wiz.lat") + " / " + t("wiz.lng")),
        h("p.small.muted", t("wiz.coords_hint")),
        h("div.grid-2", field(t("wiz.lat"), lat), field(t("wiz.lng"), lng)),
        h("button.btn.btn-ghost.btn-sm", { type: "button", on: { click: () => navigator.geolocation?.getCurrentPosition(pos => {
          lat.value = pos.coords.latitude.toFixed(5); lng.value = pos.coords.longitude.toFixed(5);
          lat.dispatchEvent(new Event("change", { bubbles: true }));
        }, () => toast(t("geo.gps_denied"), "error")) } }, icon("pin"), t("wiz.use_here"))),
      h("button.btn.btn-ghost.btn-sm", { type: "button", on: { click: () => { row.remove(); save(); } } }, t("common.remove")));
    row._get = () => ({
      workplace: val(wp), address_line: val(addr), area: val(area), division_id: geo.value.division_id,
      district_id: geo.value.district_id, upazila_id: geo.value.upazila_id, thana_id: geo.value.thana_id,
      latitude: lat.value === "" ? null : +lat.value, longitude: lng.value === "" ? null : +lng.value,
      working_hours: val(hours), is_primary: row === locs.firstElementChild,
    });
    locs.append(row);
  };
  (p.locations?.length ? p.locations : [{}]).forEach(addLoc);
  const form = h("form.card.form", { novalidate: true, on: { submit: e => e.preventDefault() } });
  const collect = () => ({
    profession: prof.value || null, designation: val(desig), experience_years: intOrNull(exp), bio: val(bio), bio_bn: val(bioBn),
    home_visit: hv.cb.checked, services: [...chosen],
    // Incomplete location rows are kept on screen but only complete ones are saved.
    locations: [...locs.children].map(r => r._get()).filter(l => l.workplace && l.division_id && l.district_id),
  });
  const save = autosaver("practice", collect, saved, form, 3);
  form.append(
    field(t("wiz.profession"), prof), h("div.grid-2", field(t("wiz.designation"), desig, null, { optional: true }), field(t("wiz.experience"), exp)),
    field(t("wiz.bio"), bio, null, { optional: true }), field(t("wiz.bio_bn"), bioBn, null, { optional: true }),
    hv.el, h("h2.h3", t("wiz.services")), servicesBox,
    h("h2.h3", t("wiz.locations")), locs,
    h("button.btn.btn-secondary.btn-sm", { type: "button", on: { click: () => addLoc() } }, "+ " + t("wiz.add_location")),
    navButtons(3, save));
  return form;
}

async function stepDocuments(app) {
  const list = h("div");
  const editable = !LOCKED.has(app.status);
  const paint = docs => clear(list).append(docs.length ? h("ul.list", docs.map(d => h("li.list-item.row-between",
    h("span", h("strong", t("doc." + d.doc_type)), h("br"), h("small.muted", d.original_name, " · ", Math.ceil(d.size_bytes / 1024) + " KB")),
    h("span.row",
      h("button.btn.btn-ghost.btn-sm", { type: "button", on: { click: () => openOwnDoc(d.id) } }, t("admin.open_doc")),
      editable ? h("button.btn.btn-ghost.btn-sm", { type: "button", on: { click: async () => {
        if (!(await confirmDialog(t("common.remove"), d.original_name, t("common.remove"), true))) return;
        try { await api.del(`/api/therapist/documents/${d.id}`); paint(await api.get("/api/therapist/documents")); } catch (err) { showError(err); }
      } } }, t("common.remove")) : null)))) : h("p.muted", t("common.none")));
  paint(app.documents);
  const type = select(DOC_TYPES.map(d => [d, t("doc." + d)]), "national_id");
  const file = h("input.input", { type: "file", accept: "application/pdf,image/jpeg,image/png" });
  const btn = h("button.btn.btn-primary", { type: "submit" }, t("wiz.upload"));
  const form = h("form.upload-form", { on: { submit: async e => {
    e.preventDefault();
    if (!file.files[0]) return;
    const fd = new FormData(); fd.append("doc_type", type.value); fd.append("file", file.files[0]);
    btn.disabled = true; btn.textContent = t("wiz.uploading");
    try { await api.upload("/api/therapist/documents", fd); file.value = ""; paint(await api.get("/api/therapist/documents")); toast(t("common.saved")); }
    catch (err) { showError(err); }
    finally { btn.disabled = false; btn.textContent = t("wiz.upload"); }
  } } }, field(t("wiz.doc_type"), type), field(t("wiz.upload"), file), btn);
  return h("div.card.form",
    h("h2.h3", t("wiz.documents")), h("p.small.muted", t("wiz.doc_hint", { mb: 10 })), h("p.alert.alert-info", t("wiz.required_docs")),
    list, editable ? form : null, navButtons(4, null));
}

async function openOwnDoc(id) {
  try {
    const blob = await api.blob(`/api/therapist/documents/${id}/file`);
    const url = URL.createObjectURL(blob);
    window.open(url, "_blank", "noopener");
    setTimeout(() => URL.revokeObjectURL(url), 60000);
  } catch (err) { showError(err); }
}

async function stepReview(app, saved) {
  const d = app.data;
  const geoNames = await resolveGeo(d.practice?.locations || []);
  const row = (k, v) => v === null || v === undefined || v === "" ? null : h("div.kv", h("span.k", k), h("span.v", String(v)));
  const decl = checkbox(t("wiz.declaration"), !!d.declaration?.accepted);
  decl.cb.addEventListener("change", async () => {
    try { await api.put("/api/therapist/application/sections/declaration", { data: { accepted: decl.cb.checked }, step: 5 });
      saved.textContent = "✓ " + t("wiz.autosaved"); refreshMissing(); }
    catch (err) { showError(err); }
  });
  const missingBox = h("div");
  async function refreshMissing() {
    const fresh = await api.get("/api/therapist/application");
    clear(missingBox).append(fresh.missing.length
      ? h("div.alert.alert-warn", h("strong", t("wiz.missing")), h("ul", fresh.missing.map(m => h("li", t("missing." + m)))))
      : null);
    submit.disabled = fresh.missing.length > 0;
  }
  const submit = h("button.btn.btn-primary.btn-lg.btn-block", { type: "button", on: { click: async () => {
    if (!(await confirmDialog(app.is_approved ? t("wiz.submit_change") : t("wiz.submit"), t("wiz.summary")))) return;
    submit.disabled = true;
    try {
      const res = await api.post("/api/therapist/application/submit");
      toast(app.is_approved ? (res.review_required ? t("wiz.change_review") : t("wiz.change_auto")) : t("wiz.submitted"));
      await refreshMe(); go("/therapist", true);
    } catch (err) {
      if (err.details?.missing) clear(missingBox).append(h("div.alert.alert-warn", h("strong", t("wiz.missing")),
        h("ul", err.details.missing.map(m => h("li", t("missing." + m))))));
      showError(err);
    } finally { submit.disabled = false; }
  } } }, app.is_approved ? t("wiz.submit_change") : t("wiz.submit"));
  const p = d.personal || {}, e = d.education || {}, pr = d.practice || {};
  const out = h("div",
    h("p.alert.alert-info", t("wiz.summary")),
    h("section.card", h("div.row-between", h("h2.h3", t("wiz.step1")), h("a.link", { href: "#/therapist/apply/1" }, t("common.edit"))),
      p.photo_key ? avatar(`/api/therapist/photo?key=${encodeURIComponent(p.photo_key)}`, p.full_name, "md") : null,
      row(t("wiz.full_name"), p.full_name), row(t("wiz.full_name_bn"), p.full_name_bn), row(t("wiz.dob"), p.date_of_birth),
      row(t("wiz.nid"), p.nid_number), row(t("wiz.email"), p.email), row(t("wiz.public_phone"), p.public_phone)),
    h("section.card", h("div.row-between", h("h2.h3", t("wiz.step2")), h("a.link", { href: "#/therapist/apply/2" }, t("common.edit"))),
      (e.qualifications || []).map(q => row(q.degree, `${q.institution}${q.passing_year ? ` (${q.passing_year})` : ""}`)),
      row(t("wiz.reg_body"), e.registration_body), row(t("wiz.reg_no"), e.registration_number)),
    h("section.card", h("div.row-between", h("h2.h3", t("wiz.step3")), h("a.link", { href: "#/therapist/apply/3" }, t("common.edit"))),
      row(t("wiz.profession"), pr.profession && t("prof." + pr.profession)), row(t("wiz.designation"), pr.designation),
      row(t("wiz.experience"), pr.experience_years), row(t("wiz.services"), (pr.services || []).map(s => t("service." + s)).join(", ")),
      (pr.locations || []).map((l, i) => row(t("wiz.workplace"), `${l.workplace} — ${geoNames[i]}`))),
    h("section.card", h("div.row-between", h("h2.h3", t("wiz.step4")), h("a.link", { href: "#/therapist/apply/4" }, t("common.edit"))),
      app.documents.map(doc => row(t("doc." + doc.doc_type), doc.original_name))),
    h("section.card", decl.el, missingBox, submit,
      app.is_approved && app.has_draft ? h("button.btn.btn-ghost.btn-block", { type: "button", on: { click: async () => {
        if (!(await confirmDialog(t("wiz.discard"), t("admin.confirm_action"), t("wiz.discard"), true))) return;
        try { await api.del("/api/therapist/application/draft"); go("/therapist", true); } catch (err) { showError(err); }
      } } }, t("wiz.discard")) : null),
    h("div.wizard-nav", h("a.btn.btn-ghost", { href: "#/therapist/apply/4" }, t("common.back"))));
  refreshMissing().catch(() => {});
  return out;
}

async function resolveGeo(locs) {
  const cache = {};
  const get = async (url, q) => (cache[url + JSON.stringify(q)] ??= await api.get(url, q));
  return Promise.all(locs.map(async l => {
    try {
      const dis = (await get("/api/geo/districts", { division_id: l.division_id })).find(x => x.id === l.district_id);
      return nm(dis);
    } catch { return ""; }
  }));
}

// ---------------------------------------------------------------------------------
// Public preview, My Patients, appointments
// ---------------------------------------------------------------------------------
export function preview() {
  const box = h("div");
  page(box);
  load(box, async () => {
    const p = await api.get("/api/therapist/public-preview");
    const name = (getLang() === "bn" && p.name_bn) || p.name;
    return [h("h1.h2", t("th.preview")),
      !p.published ? h("p.alert.alert-warn", t("th.unpublished")) : null,
      h("section.profile-head.card", avatar(p.photo_url ? p.photo_url + "?size=full" : null, name, "lg"), h("h2.h2", name),
        h("p.tcard-prof", t("prof." + p.profession), p.designation ? ` · ${p.designation}` : ""), verifiedBadge(),
        h("div.code-big", h("span", t("profile.code") + ":"), h("strong", num(p.chini_code)), codeChip(p.chini_code))),
      h("section.card", h("h2.h3", t("profile.practice")), p.locations.map(l => h("p", h("strong", l.workplace), " — ", nm(l, "district")))),
      p.services.length ? h("section.card", h("h2.h3", t("profile.services")), h("div.chips", p.services.map(s => h("span.chip", t("service." + s))))) : null,
      h("a.btn.btn-secondary.btn-block", { href: "#/therapist/apply/1" }, t("th.edit_profile"))];
  });
}

export function patients() {
  const box = h("div");
  const show = (pg = 1) => load(box, async () => {
    const data = await api.get("/api/therapist/patients", { page: pg });
    if (!data.items.length) return empty(t("mp.empty"));
    return [h("ul.list", data.items.map(p => h("li.list-item",
      h("div.row-between", h("strong", p.full_name || "—"), h("small.muted", fmtDate(p.last_interaction_at))),
      h("p.small", t("mp.via." + p.source), p.latest_appointment_status ? [" · ", t("appt.status." + p.latest_appointment_status)] : null),
      p.district_en ? h("p.small.muted", icon("pin"), nm(p, "district")) : null,
      p.phone_e164 ? h("a.btn.btn-call.btn-sm", { href: "tel:" + p.phone_e164 }, icon("phone"), p.phone_e164) : h("p.small.muted", t("mp.no_phone")),
      p.latest_message ? h("p.small.quote", p.latest_message) : null))), pager(data, show)];
  });
  page(h("h1.h2", t("mp.title")), h("p.alert.alert-info", t("mp.note")), box,
    state.config?.appointments_enabled ? h("a.btn.btn-secondary.btn-block", { href: "#/therapist/appointments" }, t("patient.appointments")) : null);
  show();
}

export function appointments() {
  const box = h("div");
  const show = (pg = 1) => load(box, async () => {
    const data = await api.get("/api/therapist/appointments", { page: pg });
    if (!data.items.length) return empty(t("appt.empty"));
    const act = (a, action) => async () => {
      let message = null;
      if (action === "accept" || action === "decline") {
        const ta = h("textarea.input", { rows: 3, maxlength: 500 });
        const ok = await modal(t("appt." + action), field(t("appt.response"), ta, null, { optional: true }),
          [{ label: t("common.cancel"), value: false }, { label: t("appt." + action), value: true, kind: "btn-primary" }]);
        if (!ok) return;
        message = ta.value.trim();
      } else if (!(await confirmDialog(t("appt." + action), t("admin.confirm_action")))) return;
      try { await api.post(`/api/therapist/appointments/${a.id}/respond`, { action, message: message || null }); show(pg); }
      catch (err) { showError(err); }
    };
    return [h("ul.list", data.items.map(a => h("li.list-item.appt",
      h("div.row-between", h("strong", a.patient_name || "—"), statusPill(a.status, "appt.status.")),
      h("p.small", fmtDate(a.preferred_date), " · ", t("appt.time." + a.preferred_time), a.service_code ? " · " + t("service." + a.service_code) : ""),
      a.patient_message ? h("p.small.quote", a.patient_message) : null,
      h("div.row",
        a.status === "requested" ? [h("button.btn.btn-primary.btn-sm", { type: "button", on: { click: act(a, "accept") } }, t("appt.accept")),
          h("button.btn.btn-ghost.btn-sm", { type: "button", on: { click: act(a, "decline") } }, t("appt.decline"))] : null,
        a.status === "accepted" ? [h("button.btn.btn-secondary.btn-sm", { type: "button", on: { click: act(a, "complete") } }, t("appt.complete")),
          h("button.btn.btn-ghost.btn-sm", { type: "button", on: { click: act(a, "cancel") } }, t("appt.cancel"))] : null)))),
      pager(data, show)];
  });
  page(h("h1.h2", t("patient.appointments")), box);
  show();
}
