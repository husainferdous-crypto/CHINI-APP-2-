// Boot, app shell (header + role-based bottom navigation) and route table.
import { api } from "./api.js";
import { getLang, setLang, storedLang, t } from "./i18n.js";
import { currentPath, fallback, go, guard, resolve, route, start } from "./router.js";
import { state } from "./state.js";
import { clear, h, icon } from "./ui.js";
import * as common from "./views/common.js";
import * as patient from "./views/patient.js";
import * as therapist from "./views/therapist.js";
import * as admin from "./views/admin.js";

export const view = () => document.getElementById("view");

export async function refreshMe() {
  try {
    const me = await api.get("/api/auth/me");
    state.user = me.user; state.csrf = me.csrf_token;
    if (me.user.language && me.user.language !== getLang()) setLang(me.user.language);
  } catch { state.user = null; state.csrf = null; }
  renderChrome();
}

export function renderChrome() {
  document.documentElement.lang = getLang();
  const header = clear(document.getElementById("app-header"));
  const home = !state.user ? "/home" : { patient: "/home", therapist: "/therapist", admin: "/admin" }[state.user.role];
  header.append(
    h("a.brand", { href: "#" + home, "aria-label": "CHINI home" },
      h("span.brand-name", "CHINI | চিনি"),
      h("span.motto", "চিনুন আসল থেরাপিস্ট")),
    h("div.header-actions",
      h("button.btn.btn-ghost.btn-sm", { type: "button", "aria-label": t("common.language"),
        on: { click: async () => {
          const next = getLang() === "bn" ? "en" : "bn";
          setLang(next);
          if (state.user) api.put("/api/auth/language", { language: next }).catch(() => {});
          renderChrome(); resolve();
        } } }, icon("globe"), getLang() === "bn" ? "English" : "বাংলা"),
      state.user && state.user.role !== "admin"
        ? h("a.icon-btn", { href: "#/notifications", "aria-label": t("notif.title") }, icon("bell"),
            state.user.unread_notifications ? h("span.dot", String(Math.min(99, state.user.unread_notifications))) : null)
        : null,
      !state.user ? h("a.btn.btn-primary.btn-sm", { href: "#/login" }, t("common.login")) : null));

  const nav = clear(document.getElementById("bottom-nav"));
  const role = state.user ? state.user.role : "guest";
  const items = {
    guest: [["/home", "home", "nav.home"], ["/search", "search", "nav.find"], ["/my-therapists", "heart", "nav.my_therapists"], ["/login", "user", "nav.profile"]],
    patient: [["/home", "home", "nav.home"], ["/search", "search", "nav.find"], ["/my-therapists", "heart", "nav.my_therapists"], ["/profile", "user", "nav.profile"]],
    therapist: [["/therapist", "grid", "nav.dashboard"], ["/therapist/profile", "user", "nav.my_profile"], ["/therapist/patients", "users", "nav.my_patients"], ["/notifications", "bell", "nav.updates"]],
    admin: [],
  }[role];
  nav.hidden = items.length === 0;
  const cur = currentPath();
  for (const [path, ic, label] of items) {
    const active = cur === path || (path !== "/home" && path !== "/therapist" && cur.startsWith(path));
    nav.append(h("a.nav-item" + (active ? ".active" : ""), { href: "#" + path, "aria-current": active ? "page" : null },
      icon(ic), h("span", t(label))));
  }
  document.body.dataset.role = role;
}

const wrap = fn => async ctx => { renderChrome(); return fn(ctx); };

route("/", wrap(() => {
  if (state.user) return go({ patient: "/home", therapist: "/therapist", admin: "/admin" }[state.user.role], true);
  return common.landing();
}));
route("/language", wrap(common.language));
route("/welcome", wrap(common.landing));
route("/login", wrap(common.login));
route("/otp", wrap(common.otp));
route("/verification", wrap(common.verification));
route("/help", wrap(common.help));
route("/privacy", wrap(common.privacy));
route("/terms", wrap(common.terms));
route("/notifications", wrap(common.notifications), { role: "any" });
route("/account/delete", wrap(common.accountDelete), { role: "any" });
route("/offline", wrap(common.offline));

route("/home", wrap(patient.home));
route("/search", wrap(patient.search));
route("/location", wrap(patient.locationScreen));
route("/t/:id", wrap(patient.therapistProfile));
route("/my-therapists", wrap(patient.myTherapists));
route("/onboarding", wrap(patient.onboarding), { role: "patient" });
route("/profile", wrap(patient.profile), { role: "patient" });
route("/appointments", wrap(patient.appointments), { role: "patient" });
route("/appointments/new/:id", wrap(patient.newAppointment), { role: "patient" });

route("/therapist", wrap(therapist.dashboard), { role: "therapist" });
route("/therapist/apply/:step", wrap(therapist.wizard), { role: "therapist" });
route("/therapist/status", wrap(therapist.status), { role: "therapist" });
route("/therapist/profile", wrap(therapist.myProfile), { role: "therapist" });
route("/therapist/preview", wrap(therapist.preview), { role: "therapist" });
route("/therapist/patients", wrap(therapist.patients), { role: "therapist" });
route("/therapist/appointments", wrap(therapist.appointments), { role: "therapist" });

route("/admin/login", wrap(admin.login));
route("/admin", wrap(admin.dashboard), { role: "admin" });
route("/admin/queue", wrap(admin.queue), { role: "admin" });
route("/admin/t/:id", wrap(admin.review), { role: "admin" });
route("/admin/doc/:id", wrap(admin.documentViewer), { role: "admin" });
route("/admin/compare/:id/:vid", wrap(admin.compare), { role: "admin" });
route("/admin/codes", wrap(admin.codes), { role: "admin" });
route("/admin/users", wrap(admin.users), { role: "admin" });
route("/admin/audit", wrap(admin.audit), { role: "admin" });
route("/admin/settings", wrap(admin.settings), { role: "admin" });
route("/admin/reports", wrap(admin.reports), { role: "admin" });
fallback(wrap(common.notFound));

// Route guards. opts.role: "patient" | "therapist" | "admin" | "any" (any signed-in user).
guard(async (opts, path) => {
  if (!storedLang() && path !== "/language") return "/language";
  if (!opts.role) return null;
  if (!state.user) {
    if (opts.role === "admin" || path.startsWith("/admin")) return "/admin/login";
    state.pendingRole = opts.role === "therapist" ? "therapist" : "patient";
    state.returnTo = path;
    return "/login";
  }
  if (opts.role !== "any" && state.user.role !== opts.role)
    return { patient: "/home", therapist: "/therapist", admin: "/admin" }[state.user.role];
  return null;
});

async function boot() {
  setLang(storedLang() || "bn");
  window.addEventListener("offline", () => document.body.classList.add("is-offline"));
  window.addEventListener("online", () => document.body.classList.remove("is-offline"));
  if (!navigator.onLine) document.body.classList.add("is-offline");
  try { state.config = await api.get("/api/config/public"); } catch { state.config = { services: {} }; }
  await refreshMe();
  if (state.user && state.user.role === "patient") {
    api.get("/api/patient/saved/ids").then(ids => { state.savedIds = new Set(ids); }).catch(() => {});
  }
  window.addEventListener("hashchange", renderChrome);
  await start();

}

boot();
