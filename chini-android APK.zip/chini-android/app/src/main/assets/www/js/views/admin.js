// Administrator web dashboard: verification queue, review, documents, versions, codes, users, audit, settings.
import { api } from "../api.js";
import { fmtDate, nm, num, t } from "../i18n.js";
import { go } from "../router.js";
import { state } from "../state.js";
import {
  avatar, clear, confirmDialog, empty, field, h, input, load, modal, pager, reasonDialog, select, showError,
  statusPill, toast,
} from "../ui.js";
import { refreshMe, view } from "../app.js";

const isSuper = () => state.user?.admin_role === "super_admin";

function shell(active, ...content) {
  const tabs = [["/admin", "admin.dashboard"], ["/admin/queue", "admin.queue"], ["/admin/queue?kind=changes", "admin.changes"],
    ["/admin/codes", "admin.codes"], ["/admin/users", "admin.users"], ["/admin/reports", "admin.reports"],
    ["/admin/audit", "admin.audit"], ["/admin/settings", "admin.settings"]];
  clear(view()).append(h("div.admin",
    h("nav.admin-tabs", { "aria-label": "admin" }, tabs.map(([href, key]) =>
      h("a" + (active === key ? ".active" : ""), { href: "#" + href }, t(key))),
      h("button.btn.btn-ghost.btn-sm", { type: "button", on: { click: async () => {
        await api.post("/api/auth/logout").catch(() => {}); state.user = null; state.csrf = null; await refreshMe(); go("/admin/login", true);
      } } }, t("common.logout"))),
    h("div.admin-body", ...content)));
}

// ---------------------------------------------------------------------------------
export function login() {
  if (state.user?.role === "admin") return go("/admin", true);
  const email = input({ name: "email", type: "email", autocomplete: "username", required: true });
  const pw = input({ name: "password", type: "password", autocomplete: "current-password", required: true });
  const totp = input({ name: "totp", inputmode: "numeric", autocomplete: "one-time-code", maxlength: 6 });
  const btn = h("button.btn.btn-primary.btn-block", { type: "submit" }, t("common.login"));
  clear(view()).append(h("div.page", h("form.card.form.narrow", { on: { submit: async e => {
    e.preventDefault(); btn.disabled = true;
    try {
      const res = await api.post("/api/admin/auth/login", { email: email.value, password: pw.value, totp: totp.value || null });
      state.csrf = res.csrf_token; await refreshMe(); go("/admin", true);
    } catch (err) { showError(err); pw.value = ""; }
    finally { btn.disabled = false; }
  } } }, h("h1.h2", t("admin.login")), field(t("admin.email"), email), field(t("admin.password"), pw),
    field(t("admin.totp"), totp), btn)));
}

// ---------------------------------------------------------------------------------
export function dashboard() {
  const box = h("div");
  shell("admin.dashboard", box);
  load(box, async () => {
    const d = await api.get("/api/admin/dashboard");
    const tile = (label, value, href) => h(href ? "a.tile" : "div.tile", href ? { href } : {}, h("strong", num(value)), h("span", label));
    const maxDiv = Math.max(1, ...d.by_division.map(x => x.n));
    return [
      h("div.tiles",
        tile(t("admin.patients"), d.patients, "#/admin/users?role=patient"), tile(t("admin.therapists"), d.therapists, "#/admin/users?role=therapist"),
        tile(t("admin.approved"), d.approved, "#/admin/queue?status=approved"), tile(t("admin.pending"), d.pending, "#/admin/queue"),
        tile(t("admin.corrections"), d.changes_requested, "#/admin/queue?status=changes_requested"),
        tile(t("admin.pending_changes"), d.pending_profile_changes, "#/admin/queue?kind=changes"),
        tile(t("admin.suspended"), d.suspended, "#/admin/users?status=suspended"),
        tile(t("admin.open_reports"), d.open_reports, "#/admin/reports"),
        tile(t("admin.deletions"), d.deletion_requests, "#/admin/users")),
      h("div.grid-2",
        h("section.card", h("h2.h3", t("admin.by_profession")),
          h("div.bars", ["PT", "OT", "SLT"].map(p => bar(t("prof." + p), d.by_profession[p], Math.max(1, d.approved))))),
        h("section.card", h("h2.h3", t("admin.code_usage")),
          bar(t("admin.codes"), d.codes.used, d.codes.capacity),
          h("p.small.muted", `active ${d.codes.active} · reserved ${d.codes.reserved} · retired ${d.codes.retired} · available ${d.codes.available}`))),
      h("div.grid-2",
        h("section.card", h("h2.h3", t("admin.by_division")), h("div.bars", d.by_division.map(x => bar(nm(x), x.n, maxDiv)))),
        h("section.card", h("h2.h3", t("admin.top_districts")),
          d.top_districts.length ? h("ul.plain", d.top_districts.map(x => h("li.row-between", h("span", nm(x)), h("strong", num(x.n))))) : h("p.muted", t("admin.no_items")))),
      h("section.card", h("h2.h3", t("admin.recent")),
        d.recent_activity.length ? h("table.table", h("tbody", d.recent_activity.map(r => h("tr",
          h("td", h("a", { href: `#/admin/t/${r.therapist_id}` }, r.display_name || `#${r.therapist_id}`)),
          h("td", statusPill(r.decision)), h("td", r.reviewer_name || ""), h("td.small", fmtDate(r.created_at, true)))))) : h("p.muted", t("admin.no_items"))),
    ];
  });
}

function bar(label, value, max) {
  const pct = Math.round((100 * (value || 0)) / (max || 1));
  return h("div.bar-row", h("span.bar-label", label), h("span.bar", h("span.bar-fill", { style: `width:${Math.min(100, pct)}%` })), h("span.bar-value", num(value || 0)));
}

// ---------------------------------------------------------------------------------
export function queue({ query }) {
  const kind = query.get("kind") === "changes" ? "changes" : "applications";
  const status = query.get("status") || "";
  const qIn = input({ type: "search", placeholder: "Name, phone or code", value: query.get("q") || "" });
  const prof = select([["", t("admin.filter_all")], ["PT", "PT"], ["OT", "OT"], ["SLT", "SLT"]], query.get("profession") || "");
  const st = select([["", t("admin.pending")], ...["draft", "submitted", "under_review", "changes_requested", "resubmitted", "approved", "rejected", "suspended"]
    .map(s => [s, t("status." + s)])], status);
  const box = h("div");
  const run = (pg = 1) => load(box, async () => {
    const data = await api.get("/api/admin/applications", { kind, status: kind === "changes" ? undefined : st.value || undefined,
      profession: prof.value || undefined, q: qIn.value.trim() || undefined, page: pg, page_size: 25 });
    if (!data.items.length) return empty(t("admin.no_items"));
    return [h("table.table", h("thead", h("tr", ["#", t("patient.full_name"), t("search.profession"), t("common.status"), t("profile.code"), t("common.date")].map(x => h("th", x)))),
      h("tbody", data.items.map(r => h("tr.clickable", { on: { click: () => go(`/admin/t/${r.therapist_id}`) } },
        h("td", String(r.therapist_id)), h("td", r.name || "—", h("br"), h("small.muted", r.phone_e164 || "")),
        h("td", r.profession || "—"), h("td", statusPill(r.status)), h("td", r.chini_code || "—"),
        h("td.small", fmtDate(r.submitted_at || r.updated_at, true)))))), pager(data, run)];
  });
  shell(kind === "changes" ? "admin.changes" : "admin.queue",
    h("form.filter-bar", { on: { submit: e => { e.preventDefault(); run(); } } }, qIn, prof, kind === "changes" ? null : st,
      h("button.btn.btn-primary.btn-sm", { type: "submit" }, t("common.search"))), box);
  run();
}

// ---------------------------------------------------------------------------------
export function review({ params }) {
  const id = +params.id;
  const box = h("div");
  shell("admin.queue", box);
  const act = (path, needReason, label) => async () => {
    let body = {};
    if (needReason) {
      const reason = await reasonDialog(label);
      if (reason === null) return;
      body = { reason };
    } else if (!(await confirmDialog(label, t("admin.confirm_action")))) return;
    try { const r = await api.post(`/api/admin/therapists/${id}/${path}`, body); toast(r?.chini_code ? `${t("profile.code")}: ${r.chini_code}` : t("common.saved")); review({ params }); }
    catch (err) { showError(err); }
  };
  load(box, async () => {
    const d = await api.get(`/api/admin/therapists/${id}`);
    const s = d.profile.status;
    const data = d.pending?.data || d.approved;
    const photo = d.pending ? `/api/admin/therapists/${id}/photo?version_id=${d.pending.version_id}` : (d.profile.approved_version_id ? `/api/admin/therapists/${id}/photo?version_id=${d.profile.approved_version_id}` : null);
    const initial = !d.profile.approved_version_id;
    const actions = h("div.action-row",
      ["submitted", "resubmitted"].includes(s) ? h("button.btn.btn-secondary", { type: "button", on: { click: act("start-review", false, t("admin.start_review")) } }, t("admin.start_review")) : null,
      d.pending ? [
        h("button.btn.btn-primary", { type: "button", on: { click: act("approve", false, t("admin.approve")) } }, t("admin.approve")),
        h("button.btn.btn-secondary", { type: "button", on: { click: act("request-changes", true, t("admin.request_changes")) } }, t("admin.request_changes")),
        h("button.btn.btn-danger", { type: "button", on: { click: act("reject", true, t("admin.reject")) } }, t("admin.reject"))] : null,
      s === "approved" ? (d.profile.published
        ? h("button.btn.btn-ghost", { type: "button", on: { click: act("unpublish", true, t("admin.unpublish")) } }, t("admin.unpublish"))
        : h("button.btn.btn-ghost", { type: "button", on: { click: act("publish", true, t("admin.publish")) } }, t("admin.publish"))) : null,
      s === "suspended"
        ? h("button.btn.btn-secondary", { type: "button", on: { click: act("reactivate", true, t("admin.reactivate")) } }, t("admin.reactivate"))
        : h("button.btn.btn-danger.btn-outline", { type: "button", on: { click: act("suspend", true, t("admin.suspend")) } }, t("admin.suspend")));
    const p = data?.personal || {}, e = data?.education || {}, pr = data?.practice || {};
    const kv = (k, v) => h("div.kv", h("span.k", k), h("span.v", v === null || v === undefined || v === "" ? "—" : String(v)));
    return [
      h("div.review-head",
        photo ? avatar(photo, p.full_name, "lg") : null,
        h("div", h("h1.h2", p.full_name || `#${id}`), h("p", statusPill(s), " ", d.profile.published ? h("span.pill.pill-approved", "published") : h("span.pill", "not published"),
          d.profile.chini_code ? h("strong.code-inline", ` ${t("profile.code")}: ${d.profile.chini_code}`) : null),
          h("p.small.muted", d.user.phone_e164 || "", " · joined ", fmtDate(d.user.created_at)))),
      actions,
      d.missing?.length ? h("div.alert.alert-warn", t("admin.missing"), " ", d.missing.join(", ")) : null,
      d.pending && !initial ? h("section.card", h("h2.h3", t("admin.changes_list")),
        changesTable(d.pending.changes), h("a.btn.btn-ghost.btn-sm", { href: `#/admin/compare/${id}/${d.pending.version_id}` }, t("admin.compare"))) : null,
      h("div.grid-2",
        h("section.card", h("h2.h3", t("admin.submitted_data")), h("p.small.muted", t("admin.private_data")),
          kv(t("wiz.full_name"), p.full_name), kv(t("wiz.full_name_bn"), p.full_name_bn), kv(t("wiz.dob"), p.date_of_birth),
          kv(t("wiz.gender"), p.gender), kv(t("wiz.nid"), p.nid_number), kv(t("wiz.email"), p.email),
          kv(t("wiz.public_phone"), `${p.public_phone || "—"} ${p.show_phone_public ? "(public)" : "(hidden)"}`),
          h("h3.h4", t("wiz.step2")), (e.qualifications || []).map(q => kv(q.degree, `${q.institution} ${q.passing_year || ""} ${q.result ? "· " + q.result : ""}`)),
          kv(t("wiz.reg_body"), e.registration_body), kv(t("wiz.reg_no"), e.registration_number), kv(t("wiz.internship"), e.internship_completed ? "✓" : "—"),
          h("h3.h4", t("wiz.step3")), kv(t("wiz.profession"), pr.profession), kv(t("wiz.designation"), pr.designation),
          kv(t("wiz.experience"), pr.experience_years), kv(t("wiz.home_visit"), pr.home_visit ? "✓" : "—"),
          kv(t("wiz.services"), (pr.services || []).join(", ")),
          (pr.locations || []).map(l => kv(t("wiz.workplace"), `${l.workplace} · ${l.address_line || ""} · div ${l.division_id} / dist ${l.district_id}${l.latitude ? ` · ${l.latitude},${l.longitude}` : ""}`)),
          pr.bio ? kv(t("wiz.bio"), pr.bio) : null),
        h("div",
          h("section.card", h("h2.h3", t("admin.documents")),
            d.documents.length ? h("ul.list", d.documents.map(doc => h("li.list-item.row-between",
              h("span", h("strong", t("doc." + doc.doc_type)), h("br"), h("small.muted", doc.original_name, " · ", Math.ceil(doc.size_bytes / 1024), " KB")),
              h("a.btn.btn-secondary.btn-sm", { href: `#/admin/doc/${doc.id}` }, t("admin.open_doc"))))) : h("p.muted", t("common.none"))),
          h("section.card", h("h2.h3", t("admin.versions")),
            h("table.table", h("tbody", d.versions.map(v => h("tr",
              h("td", "v" + v.version_no), h("td", h("span.pill.pill-" + v.status, v.status)), h("td.small", fmtDate(v.reviewed_at || v.submitted_at || v.created_at, true)),
              h("td", h("a.link", { href: `#/admin/compare/${id}/${v.id}` }, t("admin.compare")),
                isSuper() && ["approved", "superseded"].includes(v.status) && v.id !== d.profile.approved_version_id
                  ? h("button.btn.btn-ghost.btn-sm", { type: "button", on: { click: async () => {
                      const reason = await reasonDialog(t("admin.rollback")); if (reason === null) return;
                      try { await api.post(`/api/admin/therapists/${id}/versions/${v.id}/rollback`, { reason }); toast(t("common.saved")); review({ params }); }
                      catch (err) { showError(err); }
                    } } }, t("admin.rollback")) : null)))))),
          h("section.card", h("h2.h3", t("status.reviewer_note")),
            d.reviews.length ? h("ul.timeline", d.reviews.map(r => h("li", h("div.row-between", statusPill(r.decision), h("small.muted", fmtDate(r.created_at, true))),
              h("small", r.reviewer_name || ""), r.reason ? h("p", r.reason) : null))) : h("p.muted", t("common.none"))))),
    ];
  });
}

function changesTable(changes) {
  if (!changes?.length) return h("p.muted", t("common.none"));
  const show = v => (v === null || v === undefined ? "—" : typeof v === "object" ? JSON.stringify(v, null, 1) : String(v));
  return h("table.table.diff", h("thead", h("tr", h("th", t("admin.changes_list")), h("th", t("admin.before")), h("th", t("admin.after")))),
    h("tbody", changes.map(c => h("tr" + (c.critical ? ".critical" : ""),
      h("td", c.field, c.critical ? h("span.pill.pill-changes_requested", t("admin.critical")) : null),
      h("td", h("pre.diff-old", show(c.old))), h("td", h("pre.diff-new", show(c.new)))))));
}

export function compare({ params }) {
  const box = h("div");
  shell("admin.queue", box);
  load(box, async () => {
    const d = await api.get(`/api/admin/therapists/${params.id}/versions/${params.vid}/compare`);
    return [h("a.back-link", { href: `#/admin/t/${params.id}` }, "← #" + params.id),
      h("h1.h2", `${t("admin.compare")}: v${params.vid} ↔ ${d.against_id ? "v" + d.against_id : "—"}`),
      h("section.card", changesTable(d.changes))];
  });
}

export function documentViewer({ params }) {
  const box = h("div");
  shell("admin.queue", box);
  load(box, async () => {
    const blob = await api.blob(`/api/admin/documents/${params.id}`);
    const url = URL.createObjectURL(blob);
    window.addEventListener("hashchange", () => URL.revokeObjectURL(url), { once: true });
    const viewer = blob.type === "application/pdf"
      ? h("iframe.doc-frame", { src: url, title: "document" })
      : h("img.doc-image", { src: url, alt: "document" });
    return [h("button.back-link.link", { type: "button", on: { click: () => history.back() } }, "← " + t("common.back")),
      h("p.alert.alert-warn", t("admin.private_data")), viewer];
  });
}

// ---------------------------------------------------------------------------------
export function codes() {
  const lookupIn = input({ inputmode: "numeric", maxlength: 4, placeholder: "4827" });
  const result = h("div");
  const listBox = h("div");
  const filter = select([["", t("admin.filter_all")], ["active", "active"], ["reserved", "reserved"], ["retired", "retired"]], "");
  const run = (pg = 1) => load(listBox, async () => {
    const data = await api.get("/api/admin/codes", { status: filter.value || undefined, page: pg, page_size: 50 });
    const u = data.usage;
    return [h("p.small.muted", `used ${u.used}/${u.capacity} · available ${u.available}`),
      data.items.length ? h("table.table", h("tbody", data.items.map(c => h("tr",
        h("td", h("strong", c.code)), h("td", h("span.pill.pill-" + c.status, c.status)),
        h("td", c.therapist_id ? h("a", { href: `#/admin/t/${c.therapist_id}` }, c.display_name || `#${c.therapist_id}`) : (c.note || "—")),
        h("td.small", fmtDate(c.assigned_at)),
        h("td", isSuper() && c.status === "reserved" && !c.therapist_id ? h("button.btn.btn-ghost.btn-sm", { type: "button", on: { click: async () => {
          if (!(await confirmDialog(t("admin.release"), c.code))) return;
          try { await api.del(`/api/admin/codes/${c.code}/reservation`); run(pg); } catch (err) { showError(err); }
        } } }, t("admin.release")) : null))))) : empty(t("admin.no_items")),
      pager(data, run)];
  });
  filter.addEventListener("change", () => run());
  const reserveCode = input({ inputmode: "numeric", maxlength: 4 });
  const reserveNote = input({ maxlength: 200 });
  shell("admin.codes",
    h("section.card", h("h2.h3", t("admin.lookup")),
      h("form.filter-bar", { on: { submit: async e => {
        e.preventDefault();
        load(result, async () => {
          const c = await api.get(`/api/admin/codes/${encodeURIComponent(lookupIn.value.trim())}`);
          return h("div.kv-block", h("strong", c.code), " ", h("span.pill.pill-" + c.status, c.status), " ",
            c.therapist_id ? h("a", { href: `#/admin/t/${c.therapist_id}` }, c.display_name || `#${c.therapist_id}`) : c.note || "",
            c.profile_status ? [" · ", statusPill(c.profile_status)] : null);
        });
      } } }, lookupIn, h("button.btn.btn-primary.btn-sm", { type: "submit" }, t("common.search"))), result),
    isSuper() ? h("section.card", h("h2.h3", t("admin.reserve")),
      h("form.filter-bar", { on: { submit: async e => {
        e.preventDefault();
        try { await api.post("/api/admin/codes/reserve", { code: reserveCode.value.trim(), note: reserveNote.value.trim() || null }); toast(t("common.saved")); reserveCode.value = ""; run(); }
        catch (err) { showError(err); }
      } } }, reserveCode, reserveNote, h("button.btn.btn-secondary.btn-sm", { type: "submit" }, t("admin.reserve")))) : null,
    h("section.card", h("div.row-between", h("h2.h3", t("admin.codes")), filter), listBox));
  run();
}

// ---------------------------------------------------------------------------------
export function users({ query }) {
  const role = select([["", t("admin.filter_all")], ["patient", "patient"], ["therapist", "therapist"]], query.get("role") || "");
  const status = select([["", t("admin.filter_all")], ["active", "active"], ["suspended", "suspended"], ["deleted", "deleted"]], query.get("status") || "");
  const q = input({ type: "search", placeholder: "Phone, name or code" });
  const box = h("div");
  const run = (pg = 1) => load(box, async () => {
    const data = await api.get("/api/admin/users", { role: role.value || undefined, status: status.value || undefined, q: q.value.trim() || undefined, page: pg, page_size: 25 });
    if (!data.items.length) return empty(t("admin.no_items"));
    const act = (u, path, label) => async () => {
      const reason = await reasonDialog(label); if (reason === null) return;
      try { await api.post(`/api/admin/users/${u.id}/${path}`, { reason }); run(pg); } catch (err) { showError(err); }
    };
    return [h("table.table", h("thead", h("tr", ["#", "role", t("patient.full_name"), "phone", t("common.status"), ""].map(x => h("th", x)))),
      h("tbody", data.items.map(u => h("tr",
        h("td", String(u.id)), h("td", u.role), h("td", u.role === "therapist" ? h("a", { href: `#/admin/t/${u.id}` }, u.name || "—") : (u.name || "—"),
          u.deletion_requested_at ? h("span.pill.pill-rejected", t("admin.deletions")) : null),
        h("td.small", u.phone_e164 || "—"), h("td", h("span.pill.pill-" + u.status, u.status)),
        h("td.row",
          u.status === "active" ? h("button.btn.btn-ghost.btn-sm", { type: "button", on: { click: act(u, "suspend", t("admin.suspend")) } }, t("admin.suspend")) : null,
          u.status === "suspended" ? h("button.btn.btn-ghost.btn-sm", { type: "button", on: { click: act(u, "reactivate", t("admin.reactivate")) } }, t("admin.reactivate")) : null,
          isSuper() && u.role === "patient" && u.status !== "deleted" ? h("button.btn.btn-danger.btn-sm", { type: "button", on: { click: async () => {
            if (!(await confirmDialog(t("admin.erase"), t("admin.confirm_action"), t("admin.erase"), true))) return;
            try { await api.post(`/api/admin/users/${u.id}/erase`); run(pg); } catch (err) { showError(err); }
          } } }, t("admin.erase")) : null))))), pager(data, run)];
  });
  shell("admin.users", h("form.filter-bar", { on: { submit: e => { e.preventDefault(); run(); } } }, q, role, status,
    h("button.btn.btn-primary.btn-sm", { type: "submit" }, t("common.search"))), box);
  run();
}

// ---------------------------------------------------------------------------------
export function audit() {
  const action = input({ placeholder: "e.g. application.approved" });
  const target = input({ placeholder: "target id" });
  const box = h("div");
  const run = (pg = 1) => load(box, async () => {
    const data = await api.get("/api/admin/audit-logs", { action: action.value.trim() || undefined, target_id: target.value.trim() || undefined, page: pg, page_size: 50 });
    if (!data.items.length) return empty(t("admin.no_items"));
    return [h("table.table", h("thead", h("tr", [t("common.date"), t("admin.audit_actor"), t("admin.audit_action"), t("admin.audit_target"), t("common.reason"), t("common.details")].map(x => h("th", x)))),
      h("tbody", data.items.map(a => h("tr",
        h("td.small", fmtDate(a.created_at, true)), h("td", a.actor_name || `${a.actor_role || ""} ${a.actor_user_id || ""}`),
        h("td", h("code", a.action)), h("td", `${a.target_type || ""} ${a.target_id || ""}`), h("td.small", a.reason || ""),
        h("td", a.old_value || a.new_value ? h("details", h("summary.small", "…"), h("pre.small", JSON.stringify({ old: a.old_value, new: a.new_value }, null, 1))) : null))))),
      pager(data, run)];
  });
  shell("admin.audit", h("form.filter-bar", { on: { submit: e => { e.preventDefault(); run(); } } }, action, target,
    h("button.btn.btn-primary.btn-sm", { type: "submit" }, t("common.search"))), box);
  run();
}

// ---------------------------------------------------------------------------------
export function settings() {
  const box = h("div");
  shell("admin.settings", box);
  load(box, async () => {
    const s = await api.get("/api/admin/settings");
    const save = async (key, value) => {
      try { await api.put("/api/admin/settings", { key, value }); toast(t("common.saved")); }
      catch (err) { showError(err); settings(); }
    };
    const disabled = !isSuper();
    const toggle = key => {
      const cb = h("input", { type: "checkbox", checked: !!s[key], disabled, on: { change: e => save(key, e.target.checked) } });
      return h("label.check", cb, h("span", t("admin.setting." + key)));
    };
    const ratio = input({ type: "number", min: 0.5, max: 0.99, step: 0.01, value: s.chini_code_warning_ratio, disabled });
    ratio.addEventListener("change", () => save("chini_code_warning_ratio", +ratio.value));
    const block = input({ value: (s.chini_code_blocklist || []).join(", "), disabled });
    block.addEventListener("change", () => save("chini_code_blocklist", block.value.split(/[\s,]+/).filter(x => /^\d{4}$/.test(x))));
    const admins = isSuper() ? h("div") : null;
    if (admins) load(admins, async () => {
      const rows = await api.get("/api/admin/admins");
      const email = input({ type: "email", placeholder: "email" }), name = input({ placeholder: "full name" });
      const pw = input({ type: "password", placeholder: "temporary password (12+)" });
      const role = select([["reviewer", "reviewer"], ["super_admin", "super_admin"]], "reviewer");
      return [h("table.table", h("tbody", rows.map(a => h("tr", h("td", a.full_name), h("td", a.email), h("td", a.admin_role),
        h("td", a.has_2fa ? "2FA ✓" : "2FA ✗"), h("td.small", fmtDate(a.last_login_at, true)))))),
        h("form.filter-bar", { on: { submit: async e => {
          e.preventDefault();
          try {
            const r = await api.post("/api/admin/admins", { email: email.value, full_name: name.value, password: pw.value, admin_role: role.value });
            await modal("Authenticator secret (shown once)", [h("p", "Add this to the new administrator's authenticator app:"), h("pre", r.totp_secret), h("pre.small", r.otpauth_uri)],
              [{ label: t("common.close"), value: true, kind: "btn-primary" }]);
            settings();
          } catch (err) { showError(err); }
        } } }, email, name, pw, role, h("button.btn.btn-secondary.btn-sm", { type: "submit" }, "+ admin"))];
    });
    return [h("section.card.form", h("h2.h3", t("admin.settings")), disabled ? h("p.small.muted", "super_admin only") : null,
      toggle("minor_changes_require_review"), toggle("appointments_enabled"),
      field(t("admin.setting.chini_code_warning_ratio"), ratio), field(t("admin.setting.chini_code_blocklist"), block)),
      admins ? h("section.card", h("h2.h3", "Administrators"), admins) : null];
  });
}

// ---------------------------------------------------------------------------------
export function reports() {
  const st = select([["open", "open"], ["reviewed", "reviewed"], ["dismissed", "dismissed"]], "open");
  const box = h("div");
  const run = (pg = 1) => load(box, async () => {
    const data = await api.get("/api/admin/reports", { status: st.value, page: pg });
    if (!data.items.length) return empty(t("admin.no_items"));
    const close = (r, status) => async () => {
      try { await api.post(`/api/admin/reports/${r.id}/close?status=${status}`); run(pg); } catch (err) { showError(err); }
    };
    return [h("ul.list", data.items.map(r => h("li.list-item",
      h("div.row-between", h("a", { href: `#/admin/t/${r.therapist_id}` }, h("strong", r.display_name || `#${r.therapist_id}`), r.chini_code ? ` (${r.chini_code})` : ""),
        h("small.muted", fmtDate(r.created_at, true))),
      h("p", t("report.reason." + r.reason)), r.details ? h("p.small.quote", r.details) : null,
      r.status === "open" ? h("div.row", h("button.btn.btn-secondary.btn-sm", { type: "button", on: { click: close(r, "reviewed") } }, t("admin.mark_reviewed")),
        h("button.btn.btn-ghost.btn-sm", { type: "button", on: { click: close(r, "dismissed") } }, t("admin.dismiss"))) : null))), pager(data, run)];
  });
  st.addEventListener("change", () => run());
  shell("admin.reports", h("div.filter-bar", st), box);
  run();
}
