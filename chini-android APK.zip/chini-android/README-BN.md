# CHINI | চিনি — অ্যান্ড্রয়েড ডেমো অ্যাপ

এই প্রজেক্ট থেকে একটি APK তৈরি হয়। পুরো অ্যাপটি APK-এর ভেতরেই থাকে, তাই সার্ভার লাগে না এবং ইন্টারনেট ছাড়াও চলে।
সব তথ্য শুধু ফোনে থাকে; থেরাপিস্টরা কাল্পনিক। লগ ইন কোড সবসময় 123456।
অ্যাডমিন: admin@chini.local / dev-admin-password

## শুধু ফোন দিয়ে APK বানানো (GitHub, বিনামূল্যে)
1. github.com-এ অ্যাকাউন্ট খুলুন।
2. নতুন repository বানান (+ → New repository → নাম: chini-app → Public → Create)।
3. "uploading an existing file" চাপুন → chini-android.zip আপলোড করুন → Commit changes।
4. Add file → Create new file → নাম দিন: .github/workflows/build-apk.yml
   এই প্রজেক্টের .github/workflows/build-apk.yml ফাইলের লেখা পেস্ট করুন → Commit changes।
5. ৫–১০ মিনিট অপেক্ষা করুন (Actions ট্যাবে সবুজ টিক আসবে)।
6. repository-র মূল পাতায় Releases → "CHINI app" → CHINI.apk ডাউনলোড করুন।
7. ফাইলটি খুলুন → "Install unknown apps" অনুমতি দিন → Install।

## কম্পিউটার থাকলে
Android Studio দিয়ে এই ফোল্ডারটি খুলুন → Build → Build APK(s)।
